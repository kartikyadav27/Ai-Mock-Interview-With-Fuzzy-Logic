import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { sessionAPI } from '../services/api';
import toast from 'react-hot-toast';
import './InterviewPage.css';

const InterviewPage = () => {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [questions, setQuestions] = useState(location.state?.questions || []);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answer, setAnswer] = useState('');
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [sessionTimeLeft, setSessionTimeLeft] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [phase, setPhase] = useState('interview'); // interview | completing
  const timerRef = useRef(null);
  const sessionTimerRef = useRef(null);
  const startTimeRef = useRef(Date.now());

  // Load session if no questions in state
  useEffect(() => {
    if (questions.length === 0) {
      sessionAPI.getOne(sessionId).then(r => {
        const sess = r.data.session;
        setQuestions(sess.questions || []);
        setSessionTimeLeft(sess.timeLimit);
      }).catch(() => toast.error('Could not load session'));
    } else {
      setSessionTimeLeft(questions.reduce((s, q) => s + (q.timeLimit || 120), 0));
    }
  }, [sessionId, questions.length]);

  // Per-question timer
  useEffect(() => {
    if (questions.length === 0) return;
    const q = questions[currentIdx];
    setTimeLeft(q?.timeLimit || 120);
    setShowHint(false);
    startTimeRef.current = Date.now();
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { clearInterval(timerRef.current); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [currentIdx, questions]);

  // Session countdown
  useEffect(() => {
    if (sessionTimeLeft <= 0) return;
    sessionTimerRef.current = setInterval(() => {
      setSessionTimeLeft(t => {
        if (t <= 1) { clearInterval(sessionTimerRef.current); handleComplete(); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(sessionTimerRef.current);
  }, [sessionTimeLeft > 0]);

  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const handleSubmitAnswer = useCallback(async (skip = false) => {
    if (submitting) return;
    setSubmitting(true);
    clearInterval(timerRef.current);
    const timeSpent = Math.round((Date.now() - startTimeRef.current) / 1000);
    const q = questions[currentIdx];

    try {
      const res = await sessionAPI.submitAnswer(sessionId, {
        questionId: q._id,
        answerText: skip ? '' : answer,
        timeSpent,
        isSkipped: skip,
      });
      setAnswers(prev => [...prev, { ...res.data.answer, questionIdx: currentIdx }]);
      if (skip) toast('Question skipped', { icon: '⏭' });
      else toast.success(`Score: ${res.data.answer?.finalScore || 0}/100`);
    } catch (err) {
      toast.error('Failed to submit answer');
    } finally {
      setSubmitting(false);
      setAnswer('');
      if (currentIdx < questions.length - 1) {
        setCurrentIdx(i => i + 1);
      } else {
        handleComplete();
      }
    }
  }, [submitting, answer, currentIdx, questions, sessionId]);

  const handleComplete = useCallback(async () => {
    if (completing) return;
    setCompleting(true);
    setPhase('completing');
    clearInterval(timerRef.current);
    clearInterval(sessionTimerRef.current);
    try {
      await sessionAPI.complete(sessionId);
      toast.success('Interview complete! Calculating results...');
      setTimeout(() => navigate(`/results/${sessionId}`), 1500);
    } catch (err) {
      toast.error('Failed to complete interview');
      setCompleting(false);
      setPhase('interview');
    }
  }, [completing, sessionId, navigate]);

  if (questions.length === 0) {
    return <div className="loading-screen"><div className="spinner" /><p>Loading interview...</p></div>;
  }

  const q = questions[currentIdx];
  const progress = ((currentIdx) / questions.length) * 100;
  const timerPct = timeLeft / (q?.timeLimit || 120) * 100;
  const timerColor = timerPct > 50 ? '#10b981' : timerPct > 25 ? '#f59e0b' : '#ef4444';

  if (phase === 'completing') {
    return (
      <div className="interview-completing">
        <div className="completing-card">
          <div className="completing-icon">⬡</div>
          <h2>Analyzing Your Answers</h2>
          <p>Running Fuzzy Logic evaluation across all dimensions...</p>
          <div className="completing-steps">
            {['Evaluating keyword relevance', 'Measuring completeness', 'Analyzing coherence', 'Applying fuzzy rules', 'Defuzzifying scores'].map((s, i) => (
              <div key={i} className="comp-step" style={{ animationDelay: `${i * 0.4}s` }}>
                <span className="comp-dot" />
                {s}
              </div>
            ))}
          </div>
          <div className="spinner" style={{ marginTop: 24 }} />
        </div>
      </div>
    );
  }

  return (
    <div className="interview-page">
      {/* Top Bar */}
      <div className="interview-topbar">
        <div className="itb-left">
          <span className="itb-logo">⬡ InterviewAI</span>
          <span className="itb-session">Live Session</span>
        </div>
        <div className="itb-progress">
          <span>{currentIdx + 1} / {questions.length}</span>
          <div className="itb-bar">
            <div className="itb-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>
        <div className="itb-right">
          <div className="session-timer" style={{ color: sessionTimeLeft < 300 ? '#ef4444' : 'var(--text-secondary)' }}>
            ⏱ {formatTime(sessionTimeLeft)}
          </div>
          <button className="btn btn-danger btn-sm" onClick={handleComplete} disabled={completing}>
            End Interview
          </button>
        </div>
      </div>

      <div className="interview-body">
        {/* Question Panel */}
        <div className="question-panel">
          <div className="qp-header">
            <div className="qp-meta">
              <span className={`badge badge-${q.difficulty}`}>{q.difficulty}</span>
              <span className="badge badge-primary">{q.category}</span>
              <span className="qp-num">Q{currentIdx + 1}</span>
            </div>
            {/* Question Timer Ring */}
            <div className="timer-ring" title={`${timeLeft}s remaining`}>
              <svg viewBox="0 0 36 36" className="circular-chart">
                <path className="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                <path className="circle" strokeDasharray={`${timerPct}, 100`} stroke={timerColor}
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
              </svg>
              <span className="timer-text" style={{ color: timerColor }}>{formatTime(timeLeft)}</span>
            </div>
          </div>

          <div className="question-text">{q.text}</div>

          {showHint && q.hints?.length > 0 && (
            <div className="hint-box">
              <strong>💡 Hints:</strong>
              <ul>{q.hints.map((h, i) => <li key={i}>{h}</li>)}</ul>
            </div>
          )}

          <div className="qp-actions">
            {q.hints?.length > 0 && (
              <button className="btn btn-ghost btn-sm" onClick={() => setShowHint(h => !h)}>
                {showHint ? 'Hide Hint' : '💡 Show Hint'}
              </button>
            )}
          </div>

          {/* Question navigation dots */}
          <div className="q-dots">
            {questions.map((_, i) => (
              <div
                key={i}
                className={`q-dot ${i === currentIdx ? 'active' : i < currentIdx ? 'done' : ''}`}
              />
            ))}
          </div>
        </div>

        {/* Answer Panel */}
        <div className="answer-panel">
          <div className="ap-header">
            <h3>Your Answer</h3>
            <span className="word-count">{answer.trim() ? answer.trim().split(/\s+/).length : 0} words</span>
          </div>

          <textarea
            className="answer-textarea"
            placeholder="Type your answer here... Be thorough and structured. The fuzzy logic engine evaluates relevance, completeness, clarity, technical depth, and time efficiency."
            value={answer}
            onChange={e => setAnswer(e.target.value)}
            disabled={submitting}
          />

          <div className="ap-actions">
            <button
              className="btn btn-ghost"
              onClick={() => handleSubmitAnswer(true)}
              disabled={submitting}
            >
              ⏭ Skip Question
            </button>
            <button
              className="btn btn-primary btn-lg"
              onClick={() => handleSubmitAnswer(false)}
              disabled={submitting || !answer.trim()}
            >
              {submitting ? <><span className="spinner-sm" /> Evaluating...</> : 
               currentIdx === questions.length - 1 ? '✓ Submit & Finish' : '✓ Submit Answer →'}
            </button>
          </div>

          {/* Fuzzy dimensions reminder */}
          <div className="fuzzy-reminder">
            <div className="fr-title">🔮 Fuzzy Evaluation Dimensions</div>
            <div className="fr-dims">
              {['Keyword Relevance', 'Completeness', 'Clarity', 'Technical Depth', 'Time Efficiency'].map(d => (
                <span key={d} className="fr-dim">{d}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewPage;
