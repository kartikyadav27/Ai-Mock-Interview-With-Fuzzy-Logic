// HistoryPage.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { sessionAPI } from '../services/api';

const gradeColor = (g) => ({ Excellent: '#10b981', Good: '#00d4ff', Average: '#f59e0b', Poor: '#ef4444' }[g] || '#94a3b8');

const HistoryPage = () => {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [filters, setFilters] = useState({ domain: '', difficulty: '' });

  useEffect(() => {
    setLoading(true);
    sessionAPI.getAll({ page, limit: 10, status: 'completed', ...filters })
      .then(r => { setSessions(r.data.sessions || []); setTotal(r.data.total || 0); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [page, filters]);

  return (
    <div style={{ padding: '40px 0 80px' }}>
      <div className="container">
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontSize: '1.8rem', marginBottom: 8 }}>Interview History</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Review all your past mock interview sessions</p>
        </div>

        <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
          <select className="form-select" style={{ width: 180 }} value={filters.domain} onChange={e => setFilters(p => ({ ...p, domain: e.target.value }))}>
            <option value="">All Domains</option>
            {['JavaScript','Python','React','Node.js','Data Structures','Algorithms','System Design','Database','Machine Learning','Behavioral','HR'].map(d => <option key={d}>{d}</option>)}
          </select>
          <select className="form-select" style={{ width: 160 }} value={filters.difficulty} onChange={e => setFilters(p => ({ ...p, difficulty: e.target.value }))}>
            <option value="">All Difficulties</option>
            {['easy','medium','hard'].map(d => <option key={d}>{d}</option>)}
          </select>
        </div>

        {loading ? (
          <div className="loading-screen"><div className="spinner" /></div>
        ) : sessions.length === 0 ? (
          <div className="empty-state">
            <span>📭</span>
            <p>No interviews found matching your filters.</p>
            <Link to="/interview/setup" className="btn btn-primary">Start New Interview</Link>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {sessions.map(s => (
              <Link to={`/results/${s._id}`} key={s._id} style={{ textDecoration: 'none' }}>
                <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 20, padding: '16px 24px' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: '1rem', marginBottom: 6 }}>{s.title || `${s.domain} Interview`}</div>
                    <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
                      <span className={`badge badge-${s.difficulty}`}>{s.difficulty}</span>
                      <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{s.domain}</span>
                      <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{s.answeredQuestions}/{s.totalQuestions} answered</span>
                      <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{new Date(s.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: gradeColor(s.grade) }}>{s.finalScore}</div>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, color: gradeColor(s.grade) }}>{s.grade}</div>
                  </div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '1.2rem' }}>›</span>
                </div>
              </Link>
            ))}
          </div>
        )}

        {total > 10 && (
          <div style={{ display: 'flex', gap: 8, marginTop: 24, justifyContent: 'center' }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>← Prev</button>
            <span style={{ padding: '6px 14px', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>Page {page} of {Math.ceil(total / 10)}</span>
            <button className="btn btn-ghost btn-sm" onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / 10)}>Next →</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryPage;
