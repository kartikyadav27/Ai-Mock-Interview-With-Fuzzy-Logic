import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { sessionAPI } from '../services/api';
import './ResultsPage.css';

const gradeColor = (g) => ({ Excellent: '#10b981', Good: '#00d4ff', Average: '#f59e0b', Poor: '#ef4444', 'Not Answered': '#475569' }[g] || '#94a3b8');
const hiringColor = (r) => ({ 'Strong Hire': '#10b981', 'Hire': '#00d4ff', 'Consider': '#f59e0b', 'No Hire': '#ef4444' }[r] || '#94a3b8');

const ResultsPage = () => {
  const { sessionId } = useParams();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeAnswer, setActiveAnswer] = useState(0);

  useEffect(() => {
    sessionAPI.getOne(sessionId)
      .then(r => setResult(r.data.session))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [sessionId]);

  if (loading) return <div className="loading-screen"><div className="spinner" /><p>Loading results...</p></div>;
  if (!result) return <div className="loading-screen"><p>Results not found.</p></div>;

  const score = result.finalScore || 0;
  const grade = result.grade || 'N/A';
  const analysis = result.aiAnalysis || {};
  const answers = result.answers || [];

  return (
    <div className="results-page">
      <div className="container">
        {/* Header Score Card */}
        <div className="results-hero fade-in">
          <div className="rh-left">
            <div className="rh-breadcrumb">
              <Link to="/dashboard">Dashboard</Link> / Results
            </div>
            <h1>{result.title || `${result.domain} Interview`}</h1>
            <div className="rh-meta">
              <span className={`badge badge-${result.difficulty}`}>{result.difficulty}</span>
              <span>{result.domain}</span>
              <span>•</span>
              <span>{result.answeredQuestions}/{result.totalQuestions} answered</span>
              <span>•</span>
              <span>{Math.round((result.duration || 0) / 60)} min</span>
            </div>
          </div>
          <div className="rh-score">
            <div className="score-ring" style={{ '--score-color': gradeColor(grade) }}>
              <svg viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" className="sr-bg" />
                <circle cx="50" cy="50" r="42" className="sr-fill"
                  strokeDasharray={`${score * 2.638}, 264`}
                  stroke={gradeColor(grade)} />
              </svg>
              <div className="score-inner">
                <div className="score-num" style={{ color: gradeColor(grade) }}>{score}</div>
                <div className="score-max">/100</div>
              </div>
            </div>
            <div className="grade-tag" style={{ color: gradeColor(grade), borderColor: gradeColor(grade) }}>
              {grade}
            </div>
          </div>
        </div>

        {/* Hiring Recommendation */}
        {analysis.hiringRecommendation && analysis.hiringRecommendation !== 'N/A' && (
          <div className="hiring-card fade-in" style={{ borderColor: hiringColor(analysis.hiringRecommendation) }}>
            <div className="hc-left">
              <div className="hc-label">AI Hiring Recommendation</div>
              <div className="hc-value" style={{ color: hiringColor(analysis.hiringRecommendation) }}>
                {analysis.hiringRecommendation}
              </div>
            </div>
            <div className="hc-right">
              <p>{analysis.overallFeedback}</p>
            </div>
          </div>
        )}

        <div className="results-grid">
          {/* Fuzzy Score Breakdown */}
          <div className="result-card fade-in">
            <h2>🔮 Fuzzy Logic Breakdown</h2>
            <p className="card-subtitle">Scores across 5 evaluation dimensions</p>
            {result.overallFuzzyScore && (
              <div className="fuzzy-breakdown">
                {Object.entries(result.overallFuzzyScore).map(([key, val]) => (
                  <div key={key} className="fb-item">
                    <div className="fbi-header">
                      <span className="fbi-label">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <span className="fbi-val">{val}/10</span>
                    </div>
                    <div className="fbi-track">
                      <div className="fbi-fill" style={{ width: `${val * 10}%`, '--fill-color': val >= 7 ? '#10b981' : val >= 5 ? '#00d4ff' : val >= 3 ? '#f59e0b' : '#ef4444' }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* AI Insights */}
          <div className="result-card fade-in">
            <h2>🤖 AI Insights</h2>
            {analysis.topStrengths?.length > 0 && (
              <div className="insight-section">
                <div className="insight-label insight-good">✓ Strengths</div>
                <ul className="insight-list">
                  {analysis.topStrengths.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>
            )}
            {analysis.areasForImprovement?.length > 0 && (
              <div className="insight-section">
                <div className="insight-label insight-warn">⚠ Areas to Improve</div>
                <ul className="insight-list">
                  {analysis.areasForImprovement.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>
            )}
            {analysis.recommendedResources?.length > 0 && (
              <div className="insight-section">
                <div className="insight-label insight-info">📚 Resources</div>
                <ul className="insight-list">
                  {analysis.recommendedResources.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Per-Answer Breakdown */}
        <div className="answers-section fade-in">
          <h2>📝 Answer-by-Answer Review</h2>
          <div className="answers-layout">
            {/* Answer tabs */}
            <div className="answer-tabs">
              {answers.map((a, i) => (
                <button
                  key={i}
                  className={`answer-tab ${activeAnswer === i ? 'active' : ''}`}
                  style={{ '--tab-color': gradeColor(a.grade) }}
                  onClick={() => setActiveAnswer(i)}
                >
                  <span>Q{i + 1}</span>
                  <span className="at-score">{a.isSkipped ? 'Skip' : `${a.finalScore || 0}`}</span>
                  <span className="at-grade" style={{ color: gradeColor(a.grade) }}>{a.grade || 'N/A'}</span>
                </button>
              ))}
            </div>

            {/* Answer detail */}
            {answers[activeAnswer] && (
              <div className="answer-detail">
                <div className="ad-question">{answers[activeAnswer].questionText}</div>

                {answers[activeAnswer].isSkipped ? (
                  <div className="ad-skipped">⏭ Question was skipped</div>
                ) : (
                  <>
                    <div className="ad-section">
                      <div className="ads-label">Your Answer</div>
                      <div className="ad-answer-text">{answers[activeAnswer].answerText || 'No answer provided'}</div>
                    </div>

                    {answers[activeAnswer].aiEvaluation?.modelAnswer && (
                      <div className="ad-section">
                        <div className="ads-label ads-model">Model Answer</div>
                        <div className="ad-model-text">{answers[activeAnswer].aiEvaluation.modelAnswer}</div>
                      </div>
                    )}

                    {answers[activeAnswer].aiEvaluation?.feedback && (
                      <div className="ad-feedback">
                        <strong>💬 Feedback:</strong> {answers[activeAnswer].aiEvaluation.feedback}
                      </div>
                    )}

                    <div className="ad-scores">
                      {answers[activeAnswer].fuzzyScores && Object.entries(answers[activeAnswer].fuzzyScores).map(([k, v]) => (
                        <div key={k} className="ads-chip">
                          <span>{k.replace(/([A-Z])/g, ' $1').trim()}</span>
                          <strong>{Number(v).toFixed(1)}</strong>
                        </div>
                      ))}
                    </div>
                  </>
                )}

                <div className="ad-final">
                  <div>Final Score</div>
                  <div style={{ color: gradeColor(answers[activeAnswer].grade), fontSize: '2rem', fontWeight: 800, fontFamily: 'var(--font-display)' }}>
                    {answers[activeAnswer].finalScore || 0}/100
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="results-actions fade-in">
          <Link to="/interview/setup" className="btn btn-primary btn-lg">▶ New Interview</Link>
          <Link to="/history" className="btn btn-secondary">View All History</Link>
          <Link to="/analytics" className="btn btn-ghost">See Analytics →</Link>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;
