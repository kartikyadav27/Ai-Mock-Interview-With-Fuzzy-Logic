// AnalyticsPage.js
import React, { useEffect, useState } from 'react';
import { analyticsAPI } from '../services/api';

const AnalyticsPage = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    analyticsAPI.getMyAnalytics()
      .then(r => setData(r.data.analytics))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!data) return <div className="loading-screen"><p>No analytics available yet.</p></div>;

  const gradeColors = { Excellent: '#10b981', Good: '#00d4ff', Average: '#f59e0b', Poor: '#ef4444' };

  return (
    <div style={{ padding: '40px 0 80px' }}>
      <div className="container">
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontSize: '1.8rem', marginBottom: 8 }}>Performance Analytics</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Detailed insights into your interview performance</p>
        </div>

        {/* Overview Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 28 }}>
          {[
            { label: 'Total Interviews', value: data.overview?.totalInterviews || 0 },
            { label: 'Average Score', value: `${data.overview?.averageScore || 0}%` },
            { label: 'Best Score', value: `${data.overview?.bestScore || 0}%` },
            { label: 'Current Streak', value: `${data.overview?.streak || 0} days` },
          ].map((s, i) => (
            <div key={i} className="stat-card">
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginBottom: 24 }}>
          {/* Domain Performance */}
          <div className="card">
            <h2 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: 20 }}>📊 Domain Performance</h2>
            {Object.keys(data.domainStats || {}).length === 0 ? (
              <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Complete interviews to see domain stats</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {Object.entries(data.domainStats).map(([domain, stats]) => (
                  <div key={domain}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{domain} ({stats.count}x)</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem', color: stats.avgScore >= 70 ? '#10b981' : stats.avgScore >= 50 ? '#f59e0b' : '#ef4444' }}>
                        {stats.avgScore}%
                      </span>
                    </div>
                    <div style={{ height: 6, background: 'var(--bg-elevated)', borderRadius: 3, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${stats.avgScore}%`, background: 'linear-gradient(90deg, var(--accent-secondary), var(--accent-primary))', borderRadius: 3 }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Grade Distribution */}
          <div className="card">
            <h2 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: 20 }}>🏅 Grade Distribution</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {Object.entries(data.gradeDistribution || {}).map(([grade, count]) => (
                <div key={grade} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ width: 80, fontSize: '0.85rem', color: gradeColors[grade] || 'var(--text-muted)' }}>{grade}</span>
                  <div style={{ flex: 1, height: 8, background: 'var(--bg-elevated)', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${(count / (data.overview?.totalInterviews || 1)) * 100}%`, background: gradeColors[grade] || 'var(--text-muted)', borderRadius: 4 }} />
                  </div>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem', color: 'var(--text-muted)', width: 24, textAlign: 'right' }}>{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Fuzzy Averages */}
        <div className="card">
          <h2 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: 8 }}>🔮 Fuzzy Logic Dimension Averages</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: 20 }}>
            Your average scores across all 5 fuzzy evaluation dimensions ({data.trend === 'improving' ? '📈 Improving' : data.trend === 'declining' ? '📉 Declining' : '➡ Stable'} trend)
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16 }}>
            {Object.entries(data.fuzzyAverages || {}).map(([key, val]) => (
              <div key={key} style={{ textAlign: 'center', background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', padding: 16 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.6rem', fontWeight: 800, color: val >= 7 ? '#10b981' : val >= 5 ? '#00d4ff' : val >= 3 ? '#f59e0b' : '#ef4444' }}>{val}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'capitalize', marginTop: 4 }}>{key.replace(/([A-Z])/g, ' $1').trim()}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
