import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { interviewAPI, sessionAPI } from '../services/api';
import toast from 'react-hot-toast';
import './InterviewSetupPage.css';

const InterviewSetupPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    domain: searchParams.get('domain') || 'JavaScript',
    category: 'technical',
    difficulty: 'medium',
    questionCount: 5,
    timeLimit: 1800,
  });

  useEffect(() => {
    interviewAPI.getConfig()
      .then(r => setConfig(r.data))
      .catch(() => toast.error('Failed to load config'));
  }, []);

  const handleChange = (key, val) => setForm(p => ({ ...p, [key]: val }));

  const handleStart = async () => {
    setLoading(true);
    try {
      const { data } = await sessionAPI.create(form);
      await sessionAPI.start(data.session._id);
      toast.success('Interview started! Good luck! 🎯');
      navigate(`/interview/${data.session._id}`, { state: { questions: data.questions } });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create interview');
    } finally {
      setLoading(false);
    }
  };

  const difficultyInfo = {
    easy:   { label: 'Easy',   desc: 'Basic concepts, ideal for beginners',    color: '#10b981' },
    medium: { label: 'Medium', desc: 'Core topics, for 1-3 years experience',  color: '#f59e0b' },
    hard:   { label: 'Hard',   desc: 'Advanced topics, senior-level questions', color: '#ef4444' },
    mixed:  { label: 'Mixed',  desc: 'Combination of all difficulty levels',    color: '#7c3aed' },
  };

  return (
    <div className="setup-page">
      <div className="container">
        <div className="setup-header fade-in">
          <h1>Configure Your <span className="gradient-text">Interview</span></h1>
          <p>Customize your mock interview session for the best practice experience</p>
        </div>

        <div className="setup-grid fade-in">
          {/* Left: Config */}
          <div className="setup-form">
            {/* Domain */}
            <div className="setup-section">
              <h3>🎯 Domain</h3>
              <p>Select the technical area you want to practice</p>
              <div className="domain-grid">
                {config?.domains?.map(d => (
                  <button
                    key={d}
                    className={`domain-btn ${form.domain === d ? 'active' : ''}`}
                    onClick={() => handleChange('domain', d)}
                  >
                    {d}
                  </button>
                )) || <div className="spinner" />}
              </div>
            </div>

            {/* Category */}
            <div className="setup-section">
              <h3>📂 Category</h3>
              <div className="option-row">
                {config?.categories?.map(c => (
                  <button
                    key={c}
                    className={`option-btn ${form.category === c ? 'active' : ''}`}
                    onClick={() => handleChange('category', c)}
                  >
                    {c.charAt(0).toUpperCase() + c.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty */}
            <div className="setup-section">
              <h3>⚡ Difficulty</h3>
              <div className="difficulty-grid">
                {Object.entries(difficultyInfo).map(([key, info]) => (
                  <button
                    key={key}
                    className={`diff-btn ${form.difficulty === key ? 'active' : ''}`}
                    style={{ '--diff-color': info.color }}
                    onClick={() => handleChange('difficulty', key)}
                  >
                    <span className="diff-label">{info.label}</span>
                    <span className="diff-desc">{info.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Question Count */}
            <div className="setup-section">
              <h3>❓ Number of Questions</h3>
              <div className="option-row">
                {[3, 5, 7, 10].map(n => (
                  <button
                    key={n}
                    className={`option-btn ${form.questionCount === n ? 'active' : ''}`}
                    onClick={() => handleChange('questionCount', n)}
                  >
                    {n} Questions
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div className="setup-section">
              <h3>⏱ Time Limit</h3>
              <div className="option-row">
                {[
                  { label: '15 min', value: 900 },
                  { label: '30 min', value: 1800 },
                  { label: '45 min', value: 2700 },
                  { label: '60 min', value: 3600 },
                ].map(d => (
                  <button
                    key={d.value}
                    className={`option-btn ${form.timeLimit === d.value ? 'active' : ''}`}
                    onClick={() => handleChange('timeLimit', d.value)}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Summary */}
          <div className="setup-summary">
            <h3>📋 Interview Summary</h3>
            <div className="summary-items">
              <div className="sum-item"><span>Domain</span><strong>{form.domain}</strong></div>
              <div className="sum-item"><span>Category</span><strong style={{ textTransform: 'capitalize' }}>{form.category}</strong></div>
              <div className="sum-item">
                <span>Difficulty</span>
                <strong style={{ color: difficultyInfo[form.difficulty]?.color }}>
                  {difficultyInfo[form.difficulty]?.label}
                </strong>
              </div>
              <div className="sum-item"><span>Questions</span><strong>{form.questionCount}</strong></div>
              <div className="sum-item"><span>Time Limit</span><strong>{Math.round(form.timeLimit / 60)} minutes</strong></div>
              <div className="sum-item"><span>Evaluation</span><strong>Fuzzy Logic + AI</strong></div>
            </div>

            <div className="summary-info">
              <div className="info-badge">🔮 Fuzzy Logic Evaluation</div>
              <p>Each answer is evaluated across 5 dimensions using a Mamdani Fuzzy Inference System:</p>
              <ul>
                <li>📌 Keyword Relevance</li>
                <li>📝 Answer Completeness</li>
                <li>💬 Clarity & Communication</li>
                <li>🔬 Technical Depth</li>
                <li>⏱ Time Efficiency</li>
              </ul>
            </div>

            <button
              className="btn btn-primary btn-lg start-btn"
              onClick={handleStart}
              disabled={loading}
            >
              {loading ? (
                <><span className="spinner-sm" /> Setting up interview...</>
              ) : (
                '▶ Start Interview'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewSetupPage;
