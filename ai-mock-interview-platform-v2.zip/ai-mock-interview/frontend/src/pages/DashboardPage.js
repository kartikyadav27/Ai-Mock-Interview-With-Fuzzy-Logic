import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { sessionAPI, analyticsAPI } from '../services/api';
import './DashboardPage.css';

const DashboardPage = () => {
  const { user } = useAuth();
  const [recentSessions, setRecentSessions] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sessRes, analyticsRes] = await Promise.all([
          sessionAPI.getAll({ limit: 5, status: 'completed' }),
          analyticsAPI.getMyAnalytics(),
        ]);
        setRecentSessions(sessRes.data.sessions || []);
        setAnalytics(analyticsRes.data.analytics);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const gradeColor = (g) => ({ Excellent: '#10b981', Good: '#00d4ff', Average: '#f59e0b', Poor: '#ef4444' }[g] || '#94a3b8');

  const quickDomains = ['JavaScript', 'Python', 'React', 'Data Structures', 'System Design', 'Behavioral'];

  return (
    <div className="dashboard-page">
      <div className="container">
        {/* Header */}
        <div className="dash-header fade-in">
          <div>
            <h1>Welcome back, <span className="neon-text">{user?.name?.split(' ')[0]}</span> 👋</h1>
            <p>Ready to ace your next interview? Let's practice.</p>
          </div>
          <Link to="/interview/setup" className="btn btn-primary btn-lg">
            ▶ Start New Interview
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="stats-row fade-in">
          {[
            { label: 'Total Interviews', value: user?.stats?.totalInterviews || 0, icon: '📋', color: '#00d4ff' },
            { label: 'Avg Score', value: `${user?.stats?.averageScore || 0}%`, icon: '📊', color: '#10b981' },
            { label: 'Best Score', value: `${user?.stats?.bestScore || 0}%`, icon: '🏆', color: '#f59e0b' },
            { label: 'Day Streak', value: user?.stats?.streak || 0, icon: '🔥', color: '#ef4444' },
          ].map((s, i) => (
            <div className="dash-stat-card" key={i} style={{ '--accent': s.color }}>
              <div className="dsc-icon">{s.icon}</div>
              <div className="dsc-value">{s.value}</div>
              <div className="dsc-label">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="dash-grid">
          {/* Quick Start */}
          <div className="dash-section fade-in">
            <h2 className="section-title">⚡ Quick Start</h2>
            <div className="quick-domains">
              {quickDomains.map(d => (
                <Link
                  key={d}
                  to={`/interview/setup?domain=${encodeURIComponent(d)}`}
                  className="domain-chip"
                >
                  {d}
                </Link>
              ))}
            </div>
            <div className="quick-actions">
              <Link to="/interview/setup" className="quick-action-card">
                <span className="qa-icon">🎯</span>
                <div>
                  <div className="qa-title">Custom Interview</div>
                  <div className="qa-desc">Choose domain, difficulty & duration</div>
                </div>
                <span className="qa-arrow">→</span>
              </Link>
              <Link to="/history" className="quick-action-card">
                <span className="qa-icon">📖</span>
                <div>
                  <div className="qa-title">Review History</div>
                  <div className="qa-desc">See past interviews and results</div>
                </div>
                <span className="qa-arrow">→</span>
              </Link>
              <Link to="/analytics" className="quick-action-card">
                <span className="qa-icon">📈</span>
                <div>
                  <div className="qa-title">View Analytics</div>
                  <div className="qa-desc">Track your progress over time</div>
                </div>
                <span className="qa-arrow">→</span>
              </Link>
            </div>
          </div>

          {/* Recent Sessions */}
          <div className="dash-section fade-in">
            <div className="section-title-row">
              <h2 className="section-title">🕐 Recent Interviews</h2>
              <Link to="/history" className="btn btn-ghost btn-sm">View All →</Link>
            </div>
            {loading ? (
              <div className="loading-screen" style={{ minHeight: 200 }}><div className="spinner" /></div>
            ) : recentSessions.length === 0 ? (
              <div className="empty-state">
                <span>🎤</span>
                <p>No interviews yet. Start your first one!</p>
                <Link to="/interview/setup" className="btn btn-primary">Start Interview</Link>
              </div>
            ) : (
              <div className="recent-list">
                {recentSessions.map(s => (
                  <Link to={`/results/${s._id}`} key={s._id} className="recent-item">
                    <div className="ri-left">
                      <div className="ri-domain">{s.domain}</div>
                      <div className="ri-meta">
                        <span className={`badge badge-${s.difficulty}`}>{s.difficulty}</span>
                        <span>{new Date(s.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="ri-right">
                      <div className="ri-score" style={{ color: gradeColor(s.grade) }}>
                        {s.finalScore}
                      </div>
                      <div className="ri-grade" style={{ color: gradeColor(s.grade) }}>{s.grade}</div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Fuzzy Score Breakdown */}
        {analytics?.fuzzyAverages && (
          <div className="fuzzy-breakdown-card fade-in">
            <h2 className="section-title">🔮 Fuzzy Logic Performance Breakdown</h2>
            <p style={{ color: 'var(--text-secondary)', marginBottom: 24, fontSize: '0.9rem' }}>
              Average scores across all 5 fuzzy evaluation dimensions
            </p>
            <div className="fuzzy-bars">
              {Object.entries(analytics.fuzzyAverages).map(([key, val]) => (
                <div key={key} className="fb-row">
                  <div className="fb-label">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                  <div className="fb-track">
                    <div className="fb-fill" style={{ width: `${val * 10}%` }} />
                  </div>
                  <div className="fb-val">{val}/10</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
