import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/api';
import toast from 'react-hot-toast';

const ProfilePage = () => {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({
    name: user?.name || '',
    'profile.targetRole': user?.profile?.targetRole || '',
    'profile.location': user?.profile?.location || '',
    'profile.bio': user?.profile?.bio || '',
    'profile.experience': user?.profile?.experience || 0,
    'profile.linkedIn': user?.profile?.linkedIn || '',
    'profile.github': user?.profile?.github || '',
    'preferences.difficulty': user?.preferences?.difficulty || 'medium',
    'preferences.interviewDuration': user?.preferences?.interviewDuration || 30,
  });
  const [saving, setSaving] = useState(false);

  const handleChange = e => setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        profile: {
          targetRole: form['profile.targetRole'],
          location: form['profile.location'],
          bio: form['profile.bio'],
          experience: parseInt(form['profile.experience']),
          linkedIn: form['profile.linkedIn'],
          github: form['profile.github'],
        },
        preferences: {
          difficulty: form['preferences.difficulty'],
          interviewDuration: parseInt(form['preferences.interviewDuration']),
        },
      };
      const { data } = await userAPI.updateProfile(payload);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ padding: '40px 0 80px' }}>
      <div className="container" style={{ maxWidth: 700 }}>
        <h1 style={{ fontSize: '1.8rem', marginBottom: 8 }}>Profile Settings</h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: 32 }}>Manage your account and preferences</p>

        <form onSubmit={handleSave}>
          <div className="card" style={{ marginBottom: 20 }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 20 }}>👤 Personal Information</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input className="form-input" name="name" value={form.name} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label className="form-label">Target Role</label>
                <input className="form-input" name="profile.targetRole" value={form['profile.targetRole']} onChange={handleChange} placeholder="Software Engineer" />
              </div>
              <div className="form-group">
                <label className="form-label">Location</label>
                <input className="form-input" name="profile.location" value={form['profile.location']} onChange={handleChange} placeholder="City, Country" />
              </div>
              <div className="form-group">
                <label className="form-label">Years of Experience</label>
                <select className="form-select" name="profile.experience" value={form['profile.experience']} onChange={handleChange}>
                  {[0,1,2,3,5,8].map(y => <option key={y} value={y}>{y === 0 ? 'Fresher' : `${y}+ years`}</option>)}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Bio</label>
              <textarea className="form-textarea" name="profile.bio" value={form['profile.bio']} onChange={handleChange} placeholder="Tell us about yourself..." rows={3} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">LinkedIn URL</label>
                <input className="form-input" name="profile.linkedIn" value={form['profile.linkedIn']} onChange={handleChange} placeholder="https://linkedin.com/in/..." />
              </div>
              <div className="form-group">
                <label className="form-label">GitHub URL</label>
                <input className="form-input" name="profile.github" value={form['profile.github']} onChange={handleChange} placeholder="https://github.com/..." />
              </div>
            </div>
          </div>

          <div className="card" style={{ marginBottom: 24 }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 20 }}>⚙️ Interview Preferences</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Default Difficulty</label>
                <select className="form-select" name="preferences.difficulty" value={form['preferences.difficulty']} onChange={handleChange}>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Default Duration (min)</label>
                <select className="form-select" name="preferences.interviewDuration" value={form['preferences.interviewDuration']} onChange={handleChange}>
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={45}>45 minutes</option>
                  <option value={60}>60 minutes</option>
                </select>
              </div>
            </div>
          </div>

          {/* Stats Display */}
          <div className="card" style={{ marginBottom: 24 }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 16 }}>📊 Your Statistics</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              {[
                { label: 'Interviews', value: user?.stats?.totalInterviews || 0 },
                { label: 'Avg Score', value: `${user?.stats?.averageScore || 0}%` },
                { label: 'Best Score', value: `${user?.stats?.bestScore || 0}%` },
                { label: 'Streak', value: `${user?.stats?.streak || 0}d` },
              ].map((s, i) => (
                <div key={i} style={{ textAlign: 'center', background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', padding: 12 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 800, color: 'var(--accent-primary)' }}>{s.value}</div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? 'Saving...' : '✓ Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfilePage;
