import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 30000,
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      if (window.location.pathname !== '/login') window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

export const authAPI = {
  login:          (data) => api.post('/auth/login', data),
  register:       (data) => api.post('/auth/register', data),
  getMe:          ()     => api.get('/auth/me'),
  updatePassword: (data) => api.put('/auth/password', data),
};

export const userAPI = {
  getProfile:    ()     => api.get('/users/profile'),
  updateProfile: (data) => api.put('/users/profile', data),
};

export const sessionAPI = {
  create:       (data) => api.post('/sessions', data),
  getAll:       (params) => api.get('/sessions', { params }),
  getOne:       (id)   => api.get(`/sessions/${id}`),
  start:        (id)   => api.put(`/sessions/${id}/start`),
  submitAnswer: (id, data) => api.post(`/sessions/${id}/answer`, data),
  complete:     (id)   => api.put(`/sessions/${id}/complete`),
};

export const questionAPI = {
  getAll:   (params) => api.get('/questions', { params }),
  generate: (data)   => api.post('/questions/generate', data),
};

export const analyticsAPI = {
  getMyAnalytics: () => api.get('/analytics/me'),
  getLeaderboard: () => api.get('/analytics/leaderboard'),
};

export const interviewAPI = {
  getConfig: () => api.get('/interviews/config'),
};
