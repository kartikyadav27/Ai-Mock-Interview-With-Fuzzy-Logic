// NeDB embedded database — no MongoDB server needed
const db = require('./nedb');

const connectDB = async () => {
  // NeDB auto-loads from ./data/ folder on require
  console.log('✅ Database connected (NeDB embedded — no server required)');
};

module.exports = connectDB;
