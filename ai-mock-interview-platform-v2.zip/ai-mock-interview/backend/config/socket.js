const jwt = require('jsonwebtoken');
const db = require('./nedb');

module.exports = (io) => {
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) return next(new Error('Auth error'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await db.users.findOne({ _id: decoded.id });
      if (!user) return next(new Error('User not found'));
      const { password, ...safe } = user;
      socket.user = safe;
      next();
    } catch (err) {
      next(new Error('Auth error'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`🔌 Connected: ${socket.user.name}`);
    socket.on('join_interview', (sid) => socket.join(`interview_${sid}`));
    socket.on('answer_update', (data) => socket.to(`interview_${data.sessionId}`).emit('answer_received', data));
    socket.on('interview_complete', (data) => io.to(`interview_${data.sessionId}`).emit('session_ended', data));
    socket.on('disconnect', () => console.log(`🔌 Disconnected: ${socket.user.name}`));
  });
};
