const Datastore = require('nedb-promises');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = {
  users:     new Datastore({ filename: path.join(dataDir, 'users.db'),     autoload: true }),
  questions: new Datastore({ filename: path.join(dataDir, 'questions.db'), autoload: true }),
  sessions:  new Datastore({ filename: path.join(dataDir, 'sessions.db'),  autoload: true }),
};

// Create indexes
db.users.ensureIndex({ fieldName: 'email', unique: true });
db.sessions.ensureIndex({ fieldName: 'userId' });
db.questions.ensureIndex({ fieldName: 'domain' });

console.log('✅ NeDB embedded database ready (./data/)');

module.exports = db;
