/**
 * Database Seeder — uses NeDB (no MongoDB required)
 * Run: node seeder.js
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./config/nedb');

const questions = [
  // JavaScript
  { domain:'JavaScript', category:'technical', difficulty:'easy', difficultyScore:2, text:"What is the difference between var, let, and const?", expectedAnswer:"var: function-scoped, hoisted, can be redeclared. let: block-scoped, not hoisted (TDZ), cannot be redeclared. const: block-scoped, must be initialised, cannot be reassigned (but object properties can change).", keywords:["var","let","const","scope","hoisting","block","function"], hints:["Think about scope differences","Consider hoisting"], timeLimit:90, tags:["variables","ES6"] },
  { domain:'JavaScript', category:'technical', difficulty:'medium', difficultyScore:5, text:"Explain closures in JavaScript with an example.", expectedAnswer:"A closure is a function that retains access to its outer scope even after the outer function returns. Example: function counter(){ let n=0; return ()=>++n; } const c=counter(); c();//1 c();//2", keywords:["closure","scope","lexical","outer function","inner function"], hints:["How does a function remember variables?"], timeLimit:150, tags:["closures","scope"] },
  { domain:'JavaScript', category:'technical', difficulty:'hard', difficultyScore:8, text:"Explain the JavaScript Event Loop and microtask/macrotask queue.", expectedAnswer:"The Event Loop monitors Call Stack and queues. Microtasks (Promises, queueMicrotask) run after each task before the next macrotask. Macrotasks: setTimeout, setInterval, I/O. Order: sync → microtasks → next macrotask.", keywords:["event loop","call stack","microtask","macrotask","Promise","setTimeout"], hints:["What runs first — Promise or setTimeout?"], timeLimit:180, tags:["async","event loop"] },
  // React
  { domain:'React', category:'technical', difficulty:'medium', difficultyScore:5, text:"What are React Hooks? Explain useState and useEffect with examples.", expectedAnswer:"Hooks are functions that let functional components use state and lifecycle. useState returns [state, setter]. useEffect runs side effects after render, dependency array controls when it re-runs.", keywords:["hooks","useState","useEffect","functional","dependency array","side effects"], hints:["What problem did hooks solve?"], timeLimit:150, tags:["hooks","React"] },
  { domain:'React', category:'technical', difficulty:'hard', difficultyScore:7, text:"Explain React's reconciliation algorithm and virtual DOM.", expectedAnswer:"React creates a virtual DOM tree and on re-render diffs it with the previous tree (reconciliation). Only changed nodes are updated in the real DOM (patching). Keys help React identify list items efficiently.", keywords:["virtual DOM","reconciliation","diffing","fiber","keys","render"], hints:["Why is direct DOM manipulation slow?"], timeLimit:150, tags:["virtual DOM","performance"] },
  // Data Structures
  { domain:'Data Structures', category:'technical', difficulty:'easy', difficultyScore:2, text:"Explain the difference between a stack and a queue.", expectedAnswer:"Stack: LIFO (Last In First Out). Operations: push, pop. Example: browser back, undo/redo, call stack. Queue: FIFO (First In First Out). Operations: enqueue, dequeue. Example: print queue, task scheduling.", keywords:["LIFO","FIFO","stack","queue","push","pop","enqueue","dequeue"], hints:["Think about order of access"], timeLimit:90, tags:["stack","queue"] },
  { domain:'Data Structures', category:'technical', difficulty:'medium', difficultyScore:5, text:"What is a binary search tree? What are its time complexities?", expectedAnswer:"BST: each node has left child < node < right child. Search/insert/delete: O(log n) average, O(n) worst (unbalanced). In-order traversal gives sorted output. Balanced BSTs (AVL, Red-Black) guarantee O(log n).", keywords:["BST","binary search","O(log n)","balanced","traversal","insert","delete"], hints:["How does it differ from a regular binary tree?"], timeLimit:150, tags:["BST","trees"] },
  // Algorithms
  { domain:'Algorithms', category:'technical', difficulty:'medium', difficultyScore:6, text:"Explain merge sort and its time complexity.", expectedAnswer:"Divide-and-conquer: recursively split array in halves, then merge sorted halves. Time: O(n log n) all cases. Space: O(n). Stable. Better for linked lists and external sorting than quicksort.", keywords:["merge sort","divide","conquer","O(n log n)","stable","recursive"], hints:["How do you merge two sorted arrays?"], timeLimit:180, tags:["sorting","complexity"] },
  { domain:'Algorithms', category:'technical', difficulty:'medium', difficultyScore:5, text:"What is Big O notation? Explain O(1), O(n), O(n²), and O(log n).", expectedAnswer:"Big O describes worst-case growth rate. O(1): array index access. O(n): linear search. O(n²): nested loops/bubble sort. O(log n): binary search. Ignores constants and lower-order terms.", keywords:["Big O","O(1)","O(n)","O(log n)","O(n²)","complexity","worst case"], hints:["How does runtime grow as input doubles?"], timeLimit:120, tags:["complexity","Big O"] },
  // System Design
  { domain:'System Design', category:'technical', difficulty:'hard', difficultyScore:9, text:"How would you design a URL shortening service like bit.ly?", expectedAnswer:"Core: API accepts long URL, returns short code (base62 hash). Store mapping in NoSQL DB. Redirect service (301/302). Redis cache for hot URLs. Handle collisions, custom aliases, expiry, analytics, rate limiting.", keywords:["hashing","base62","NoSQL","Redis","cache","redirect","rate limiting","collision"], hints:["What are the 2 main operations?","How do you generate a short code?"], timeLimit:300, tags:["system design","scalability"] },
  // Database
  { domain:'Database', category:'technical', difficulty:'medium', difficultyScore:5, text:"Explain the difference between SQL and NoSQL databases.", expectedAnswer:"SQL: relational, ACID, fixed schema, vertical scaling, joins. Use for transactions, complex queries. NoSQL: flexible schema, horizontal scaling. Types: document, key-value, graph, column. Use for unstructured/high-volume data.", keywords:["SQL","NoSQL","ACID","relational","schema","horizontal scaling","vertical scaling"], hints:["What does ACID guarantee?"], timeLimit:150, tags:["database","SQL","NoSQL"] },
  // Python
  { domain:'Python', category:'technical', difficulty:'medium', difficultyScore:6, text:"What are Python decorators? Write a simple logging decorator.", expectedAnswer:"Decorators wrap functions to add behaviour. @syntax is sugar for func=decorator(func). Example: def log(fn): def wrap(*a,**kw): print(fn.__name__); return fn(*a,**kw); return wrap", keywords:["decorator","wrapper","@","higher-order","function","syntax"], hints:["@ is just syntactic sugar"], timeLimit:150, tags:["python","decorators"] },
  // Node.js
  { domain:'Node.js', category:'technical', difficulty:'medium', difficultyScore:5, text:"Explain middleware in Express.js with an example.", expectedAnswer:"Middleware are functions (req, res, next) in the request pipeline. Can modify req/res, end cycle, or call next(). Types: application, router, error, built-in, third-party. Example: logger, auth check.", keywords:["middleware","req","res","next","pipeline","Express","app.use"], hints:["What does next() do?"], timeLimit:150, tags:["nodejs","express","middleware"] },
  // Behavioral
  { domain:'Behavioral', category:'behavioral', difficulty:'medium', difficultyScore:4, text:"Tell me about a time you faced a significant technical challenge. How did you overcome it?", expectedAnswer:"Use STAR method: Situation (context), Task (responsibility), Action (specific steps), Result (outcome with metrics). Show problem-solving, persistence, collaboration, and learning from the experience.", keywords:["STAR","challenge","solution","result","learning","teamwork","problem-solving"], hints:["Use STAR framework","Quantify the result if possible"], timeLimit:180, tags:["behavioral","STAR"] },
  // HR
  { domain:'HR', category:'hr', difficulty:'easy', difficultyScore:2, text:"Where do you see yourself in 5 years?", expectedAnswer:"Show ambition aligned with realistic growth. Mention: specific skill development, leadership aspirations, contributing to larger projects, continuous learning mindset. Align with company's direction. Avoid generic answers.", keywords:["growth","goals","leadership","skills","learning","contribute","ambition"], hints:["Research the company growth trajectory","Be specific not vague"], timeLimit:90, tags:["HR","career goals"] },
  // Machine Learning
  { domain:'Machine Learning', category:'technical', difficulty:'medium', difficultyScore:6, text:"Explain overfitting and how to prevent it.", expectedAnswer:"Overfitting: model memorises training data, fails on unseen data (high variance, low bias). Prevention: L1/L2 regularisation, dropout, cross-validation, early stopping, data augmentation, simpler model architecture.", keywords:["overfitting","variance","bias","regularisation","dropout","cross-validation","generalisation"], hints:["What's the difference between training and test accuracy?"], timeLimit:150, tags:["ML","overfitting"] },
];

const seed = async () => {
  try {
    // Clear existing data
    await db.questions.remove({}, { multi:true });
    await db.users.remove({ email:'admin@mockinterview.com' }, {});
    console.log('🗑️  Cleared old seed data');

    // Insert questions
    const inserted = await db.questions.insert(questions.map(q => ({
      ...q, isActive:true, usageCount:0, avgScore:0,
      followUpQuestions: q.followUpQuestions || [],
      createdAt: new Date().toISOString(),
    })));
    console.log(`✅ Seeded ${inserted.length} questions`);

    // Create admin user
    const hashed = await bcrypt.hash('Admin@123456', 12);
    const now = new Date().toISOString();
    await db.users.insert({
      name:'Admin User', email:'admin@mockinterview.com', password:hashed, role:'admin',
      profile:{ avatar:'',phone:'',location:'India',bio:'Platform administrator',skills:['JavaScript','React','Node.js'],experience:5,targetRole:'Senior Engineer',linkedIn:'',github:'' },
      stats:{ totalInterviews:0,averageScore:0,bestScore:0,totalTimeSpent:0,streak:0,lastInterviewDate:null },
      preferences:{ difficulty:'hard',interviewDuration:45,preferredDomains:['JavaScript','System Design'],notificationsEnabled:true },
      isActive:true, lastLogin:now, createdAt:now, updatedAt:now,
    });
    console.log('✅ Admin created: admin@mockinterview.com / Admin@123456');

    // Create demo candidate
    const hashed2 = await bcrypt.hash('Demo@123456', 12);
    await db.users.insert({
      name:'Demo Student', email:'demo@mockinterview.com', password:hashed2, role:'candidate',
      profile:{ avatar:'',phone:'',location:'Mumbai, India',bio:'CS student preparing for placements',skills:['JavaScript','Python','React'],experience:0,targetRole:'Software Engineer',linkedIn:'',github:'' },
      stats:{ totalInterviews:0,averageScore:0,bestScore:0,totalTimeSpent:0,streak:0,lastInterviewDate:null },
      preferences:{ difficulty:'medium',interviewDuration:30,preferredDomains:['JavaScript','Data Structures'],notificationsEnabled:true },
      isActive:true, lastLogin:now, createdAt:now, updatedAt:now,
    });
    console.log('✅ Demo user created: demo@mockinterview.com / Demo@123456');

    console.log('\n🎉 Database seeded successfully!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('  Admin  : admin@mockinterview.com / Admin@123456');
    console.log('  Demo   : demo@mockinterview.com  / Demo@123456');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seeder error:', err.message);
    process.exit(1);
  }
};

seed();
