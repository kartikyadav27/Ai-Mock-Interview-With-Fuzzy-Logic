const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

// Ensure data directory exists
const fs = require('fs');
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const connectDB = require('./config/db');
connectDB();

const app = express();
const server = http.createServer(app);

const io = socketIo(server, {
  cors: { origin: process.env.FRONTEND_URL || 'http://localhost:3000', methods:['GET','POST'], credentials:true },
});
app.set('io', io);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000', credentials:true }));
app.use(express.json({ limit:'10mb' }));
app.use(express.urlencoded({ extended:true }));
if (process.env.NODE_ENV !== 'production') app.use(morgan('dev'));

// Routes
app.use('/api/auth',      require('./routes/authRoutes'));
app.use('/api/users',     require('./routes/userRoutes'));
app.use('/api/interviews',require('./routes/interviewRoutes'));
app.use('/api/sessions',  require('./routes/sessionRoutes'));
app.use('/api/questions', require('./routes/questionRoutes'));
app.use('/api/results',   require('./routes/resultRoutes'));
app.use('/api/analytics', require('./routes/analyticsRoutes'));

app.get('/api/health', (req, res) => res.json({ success:true, message:'Server running', db:'NeDB embedded', timestamp:new Date() }));

require('./config/socket')(io);
app.use(require('./middleware/errorHandler'));
app.use((req, res) => res.status(404).json({ success:false, message:'Route not found' }));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log('\n' + '═'.repeat(50));
  console.log(`  🚀  Server running on http://localhost:${PORT}`);
  console.log(`  📦  Database: NeDB (embedded, no install needed)`);
  console.log(`  🔗  API: http://localhost:${PORT}/api/health`);
  console.log('═'.repeat(50) + '\n');
});

module.exports = { app, server };
