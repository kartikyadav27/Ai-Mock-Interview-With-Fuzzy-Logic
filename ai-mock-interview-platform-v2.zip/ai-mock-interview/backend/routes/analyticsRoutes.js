// analyticsRoutes.js
const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { getUserAnalytics, getLeaderboard } = require('../controllers/analyticsController');

router.get('/me', protect, getUserAnalytics);
router.get('/leaderboard', protect, getLeaderboard);

module.exports = router;
