// interviewRoutes.js
const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');

// Available domains and config for frontend
router.get('/config', protect, (req, res) => {
  res.json({
    success: true,
    domains: [
      'JavaScript', 'Python', 'Java', 'C++', 'React', 'Node.js',
      'Data Structures', 'Algorithms', 'System Design', 'Database',
      'Machine Learning', 'DevOps', 'Behavioral', 'HR', 'General',
    ],
    categories: ['technical', 'behavioral', 'situational', 'hr', 'coding'],
    difficulties: ['easy', 'medium', 'hard', 'mixed'],
    questionCounts: [3, 5, 7, 10],
    durations: [
      { label: '15 minutes', value: 900 },
      { label: '30 minutes', value: 1800 },
      { label: '45 minutes', value: 2700 },
      { label: '60 minutes', value: 3600 },
    ],
  });
});

module.exports = router;
