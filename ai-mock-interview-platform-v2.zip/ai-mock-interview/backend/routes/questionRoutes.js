const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const db = require('../config/nedb');
const aiService = require('../services/aiEvaluationService');

router.get('/', protect, async (req, res) => {
  try {
    const { domain, difficulty, category, limit=20, page=1 } = req.query;
    let query = { isActive:true };
    if (domain) query.domain = domain;
    if (difficulty) query.difficulty = difficulty;
    if (category) query.category = category;
    const all = await db.questions.find(query);
    const total = all.length;
    const questions = all.slice((page-1)*limit, page*limit);
    res.json({ success:true, questions, total, pages:Math.ceil(total/limit) });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

router.post('/', protect, authorize('admin'), async (req, res) => {
  try {
    const q = await db.questions.insert({ ...req.body, isActive:true, usageCount:0, avgScore:0, createdBy:req.user._id, createdAt:new Date().toISOString() });
    res.status(201).json({ success:true, question:q });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

router.post('/generate', protect, async (req, res) => {
  try {
    const { domain, difficulty='medium', count=5, category='technical' } = req.body;
    const aiQs = await aiService.generateQuestions(domain, difficulty, count, category);
    const saved = await Promise.all(aiQs.map(q => db.questions.insert({ ...q, domain, category, difficulty, isActive:true, usageCount:0, avgScore:0, createdBy:req.user._id, createdAt:new Date().toISOString() })));
    res.status(201).json({ success:true, questions:saved, count:saved.length });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

module.exports = router;
