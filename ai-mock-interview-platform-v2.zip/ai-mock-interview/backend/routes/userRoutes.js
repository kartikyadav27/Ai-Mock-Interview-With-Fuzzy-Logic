const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const db = require('../config/nedb');

router.get('/profile', protect, async (req, res) => {
  try {
    const user = await db.users.findOne({ _id:req.user._id });
    const { password, ...safe } = user;
    res.json({ success:true, user:safe });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

router.put('/profile', protect, async (req, res) => {
  try {
    const allowed = ['name','profile','preferences'];
    const updates = {};
    allowed.forEach(f => { if (req.body[f]!==undefined) updates[f] = req.body[f]; });
    updates.updatedAt = new Date().toISOString();
    await db.users.update({ _id:req.user._id }, { $set: updates });
    const user = await db.users.findOne({ _id:req.user._id });
    const { password, ...safe } = user;
    res.json({ success:true, user:safe });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

router.get('/', protect, authorize('admin'), async (req, res) => {
  try {
    const users = (await db.users.find({})).map(({ password, ...u }) => u);
    res.json({ success:true, users, count:users.length });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

module.exports = router;
