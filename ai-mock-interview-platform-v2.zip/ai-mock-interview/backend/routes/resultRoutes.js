const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const db = require('../config/nedb');

router.get('/:sessionId', protect, async (req, res) => {
  try {
    const session = await db.sessions.findOne({ _id:req.params.sessionId, userId:req.user._id, status:'completed' });
    if (!session) return res.status(404).json({ success:false, message:'Result not found' });
    const questions = await Promise.all((session.questionIds||[]).map(id => db.questions.findOne({ _id:id })));
    session.questions = questions.filter(Boolean);
    res.json({ success:true, result:session });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

module.exports = router;
