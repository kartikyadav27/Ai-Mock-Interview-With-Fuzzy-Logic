const express = require('express');
const router = express.Router();
const {
  createSession,
  startSession,
  submitAnswer,
  completeSession,
  getSessions,
  getSession,
} = require('../controllers/sessionController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.post('/', createSession);
router.get('/', getSessions);
router.get('/:id', getSession);
router.put('/:id/start', startSession);
router.post('/:id/answer', submitAnswer);
router.put('/:id/complete', completeSession);

module.exports = router;
