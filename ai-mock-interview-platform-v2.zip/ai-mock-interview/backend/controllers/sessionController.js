const db = require('../config/nedb');
const fuzzyEngine = require('../services/fuzzyLogicEngine');
const aiService = require('../services/aiEvaluationService');

// POST /api/sessions
exports.createSession = async (req, res) => {
  const { domain, category='technical', difficulty='medium', questionCount=5, timeLimit=1800 } = req.body;
  try {
    let query = { domain, isActive:true };
    if (difficulty !== 'mixed') query.difficulty = difficulty;
    if (category !== 'mixed') query.category = category;

    let questions = await db.questions.find(query);
    questions = questions.sort(() => 0.5 - Math.random()).slice(0, questionCount);

    // If not enough, generate with AI
    if (questions.length < questionCount) {
      try {
        const needed = questionCount - questions.length;
        const aiQs = await aiService.generateQuestions(domain, difficulty === 'mixed' ? 'medium' : difficulty, needed, category === 'mixed' ? 'technical' : category);
        const saved = await Promise.all(aiQs.map(q => db.questions.insert({
          ...q, domain, category: category === 'mixed' ? 'technical' : category,
          difficulty: difficulty === 'mixed' ? 'medium' : difficulty,
          isActive:true, usageCount:0, avgScore:0,
          createdAt: new Date().toISOString()
        })));
        questions = [...questions, ...saved];
      } catch(e) { console.error('AI question gen failed:', e.message); }
    }

    // Fallback: if still no questions, pull any from any domain
    if (questions.length === 0) {
      questions = await db.questions.find({ isActive:true });
      questions = questions.sort(() => 0.5 - Math.random()).slice(0, questionCount);
    }

    if (questions.length === 0)
      return res.status(404).json({ success:false, message:'No questions found. Please run the seeder first.' });

    const now = new Date().toISOString();
    const session = await db.sessions.insert({
      userId: req.user._id,
      title: `${domain} - ${difficulty} Interview`,
      domain, category, difficulty,
      questionIds: questions.map(q => q._id),
      answers: [],
      totalQuestions: questions.length,
      answeredQuestions: 0, skippedQuestions: 0,
      status: 'scheduled', timeLimit,
      overallFuzzyScore: { relevance:0, completeness:0, clarity:0, technicalDepth:0, communication:0 },
      finalScore:0, grade:'N/A',
      aiAnalysis: { overallFeedback:'', topStrengths:[], areasForImprovement:[], recommendedResources:[], hiringRecommendation:'N/A' },
      startedAt:null, completedAt:null, duration:0,
      createdAt:now, updatedAt:now,
    });

    res.status(201).json({
      success:true,
      session: { _id:session._id, title:session.title, domain:session.domain, difficulty:session.difficulty, totalQuestions:session.totalQuestions, timeLimit:session.timeLimit, status:session.status },
      questions: questions.map(q => ({ _id:q._id, text:q.text, difficulty:q.difficulty, category:q.category, timeLimit:q.timeLimit||120, hints:q.hints||[] })),
    });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

// PUT /api/sessions/:id/start
exports.startSession = async (req, res) => {
  try {
    const session = await db.sessions.findOne({ _id:req.params.id, userId:req.user._id });
    if (!session) return res.status(404).json({ success:false, message:'Session not found' });
    await db.sessions.update({ _id:session._id }, { $set:{ status:'in_progress', startedAt:new Date().toISOString() } });
    res.json({ success:true, message:'Interview started' });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

// POST /api/sessions/:id/answer
exports.submitAnswer = async (req, res) => {
  const { questionId, answerText='', timeSpent=60, isSkipped=false } = req.body;
  try {
    const session = await db.sessions.findOne({ _id:req.params.id, userId:req.user._id });
    if (!session) return res.status(404).json({ success:false, message:'Session not found' });

    const question = await db.questions.findOne({ _id:questionId });
    if (!question) return res.status(404).json({ success:false, message:'Question not found' });

    let evalResult = { fuzzyScores:{relevance:0,completeness:0,clarity:0,technicalDepth:0,communication:0}, fuzzyMembership:{poor:1,average:0,good:0,excellent:0}, finalScore:0, grade:'Not Answered' };
    let aiEval = { feedback:'', strengths:[], improvements:[], modelAnswer: question.expectedAnswer||'' };

    if (!isSkipped && answerText.trim()) {
      try {
        const full = await aiService.evaluateAnswer(question, answerText, timeSpent, question.timeLimit||120);
        evalResult = { fuzzyScores: full.crispInputs, fuzzyMembership: full.fuzzyMembership, finalScore: full.finalScore, grade: full.grade };
        aiEval = full.aiEvaluation || aiEval;
      } catch(e) {
        // Fallback to pure fuzzy without AI
        const fuzzy = fuzzyEngine.evaluate({ answer:answerText, expectedAnswer:question.expectedAnswer, keywords:question.keywords||[], timeSpent, timeLimit:question.timeLimit||120, aiRelevanceScore:5, aiCoherenceScore:5 });
        evalResult = { fuzzyScores:fuzzy.crispInputs, fuzzyMembership:fuzzy.fuzzyMembership, finalScore:fuzzy.finalScore, grade:fuzzy.grade };
        aiEval.modelAnswer = question.expectedAnswer||'';
      }
    }

    const answerObj = { questionId, questionText:question.text, answerText: isSkipped?'':answerText, timeSpent, isSkipped, ...evalResult, aiEvaluation:aiEval };

    const answers = session.answers || [];
    const existingIdx = answers.findIndex(a => a.questionId === questionId);
    if (existingIdx >= 0) answers[existingIdx] = answerObj; else answers.push(answerObj);

    const answered = answers.filter(a => !a.isSkipped).length;
    const skipped  = answers.filter(a =>  a.isSkipped).length;
    await db.sessions.update({ _id:session._id }, { $set:{ answers, answeredQuestions:answered, skippedQuestions:skipped } });

    res.json({ success:true, answer:answerObj, message: isSkipped?'Skipped':'Evaluated' });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

// PUT /api/sessions/:id/complete
exports.completeSession = async (req, res) => {
  try {
    const session = await db.sessions.findOne({ _id:req.params.id, userId:req.user._id });
    if (!session) return res.status(404).json({ success:false, message:'Session not found' });

    const now = new Date();
    const startedAt = session.startedAt ? new Date(session.startedAt) : now;
    const duration = Math.round((now - startedAt) / 1000);
    const answers = session.answers || [];
    const scored = answers.filter(a => !a.isSkipped && a.finalScore > 0);

    let finalScore = 0;
    const overallFuzzyScore = { relevance:0, completeness:0, clarity:0, technicalDepth:0, communication:0 };
    if (scored.length > 0) {
      finalScore = Math.round(scored.reduce((s,a) => s+(a.finalScore||0), 0) / scored.length);
      Object.keys(overallFuzzyScore).forEach(k => {
        overallFuzzyScore[k] = Math.round(scored.reduce((s,a) => s+((a.fuzzyScores&&a.fuzzyScores[k])||0),0) / scored.length * 10)/10;
      });
    }

    const grade = fuzzyEngine.getGrade(finalScore);

    let aiAnalysis = { overallFeedback:`You scored ${finalScore}/100 on this ${session.domain} interview.`, topStrengths:['Completed the interview'], areasForImprovement:['Review core concepts'], recommendedResources:['LeetCode','MDN Docs'], hiringRecommendation: finalScore>=70?'Hire':finalScore>=50?'Consider':'No Hire' };
    try { aiAnalysis = await aiService.generateSessionFeedback({ domain:session.domain, answers, finalScore }); } catch(e) {}

    await db.sessions.update({ _id:session._id }, { $set:{ status:'completed', completedAt:now.toISOString(), duration, finalScore, grade, overallFuzzyScore, aiAnalysis, answeredQuestions: answers.filter(a=>!a.isSkipped).length, skippedQuestions: answers.filter(a=>a.isSkipped).length } });

    // Update user stats
    const user = await db.users.findOne({ _id:req.user._id });
    const ti = (user.stats.totalInterviews||0) + 1;
    const newAvg = Math.round(((user.stats.averageScore||0)*(ti-1) + finalScore) / ti);
    const newBest = Math.max(user.stats.bestScore||0, finalScore);
    await db.users.update({ _id:user._id }, { $set:{ 'stats.totalInterviews':ti, 'stats.averageScore':newAvg, 'stats.bestScore':newBest, 'stats.lastInterviewDate':now.toISOString(), 'stats.totalTimeSpent':(user.stats.totalTimeSpent||0)+Math.round(duration/60) } });

    res.json({ success:true, message:'Interview completed!', result:{ sessionId:session._id, finalScore, grade, totalQuestions:session.totalQuestions, answeredQuestions:session.answeredQuestions, duration, overallFuzzyScore, aiAnalysis } });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

// GET /api/sessions
exports.getSessions = async (req, res) => {
  const { page=1, limit=10, status, domain } = req.query;
  try {
    let query = { userId:req.user._id };
    if (status) query.status = status;
    if (domain) query.domain = domain;
    const all = await db.sessions.find(query).sort({ createdAt:-1 });
    const total = all.length;
    const sessions = all.slice((page-1)*limit, page*limit).map(s => {
      const { answers, ...rest } = s; return rest;
    });
    res.json({ success:true, sessions, total, pages:Math.ceil(total/limit) });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

// GET /api/sessions/:id
exports.getSession = async (req, res) => {
  try {
    const session = await db.sessions.findOne({ _id:req.params.id, userId:req.user._id });
    if (!session) return res.status(404).json({ success:false, message:'Session not found' });
    // Populate questions
    const questions = await Promise.all((session.questionIds||[]).map(id => db.questions.findOne({ _id:id })));
    session.questions = questions.filter(Boolean);
    res.json({ success:true, session });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};
