const db = require('../config/nedb');

exports.getUserAnalytics = async (req, res) => {
  try {
    const sessions = await db.sessions.find({ userId:req.user._id, status:'completed' });
    sessions.sort((a,b) => new Date(a.createdAt)-new Date(b.createdAt));
    const user = await db.users.findOne({ _id:req.user._id });
    const { password, ...safeUser } = user;

    const scoreHistory = sessions.map(s => ({ date:s.createdAt, score:s.finalScore, domain:s.domain, grade:s.grade }));

    const domainStats = {};
    sessions.forEach(s => {
      if (!domainStats[s.domain]) domainStats[s.domain] = { count:0, totalScore:0, avgScore:0 };
      domainStats[s.domain].count++;
      domainStats[s.domain].totalScore += s.finalScore||0;
    });
    Object.keys(domainStats).forEach(d => {
      domainStats[d].avgScore = Math.round(domainStats[d].totalScore / domainStats[d].count);
    });

    const gradeDistribution = { Excellent:0, Good:0, Average:0, Poor:0 };
    sessions.forEach(s => { if (gradeDistribution[s.grade]!==undefined) gradeDistribution[s.grade]++; });

    const fuzzyAverages = { relevance:0, completeness:0, clarity:0, technicalDepth:0, communication:0 };
    if (sessions.length > 0) {
      sessions.forEach(s => { if (s.overallFuzzyScore) Object.keys(fuzzyAverages).forEach(k => { fuzzyAverages[k] += s.overallFuzzyScore[k]||0; }); });
      Object.keys(fuzzyAverages).forEach(k => { fuzzyAverages[k] = Math.round(fuzzyAverages[k]/sessions.length*10)/10; });
    }

    const recent = [...sessions].reverse().slice(0,5);
    const trend = recent.length>=2 ? (recent[0].finalScore>recent[recent.length-1].finalScore?'improving':'declining') : 'stable';

    res.json({ success:true, analytics:{ overview:safeUser.stats, scoreHistory, domainStats, gradeDistribution, fuzzyAverages, trend, recentSessions:recent.slice(0,5) } });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

exports.getLeaderboard = async (req, res) => {
  try {
    const users = await db.users.find({ isActive:true });
    const board = users.filter(u => (u.stats?.totalInterviews||0)>0)
      .sort((a,b) => (b.stats?.averageScore||0)-(a.stats?.averageScore||0))
      .slice(0,20)
      .map(({ password, ...u }) => u);
    res.json({ success:true, leaderboard:board });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};
