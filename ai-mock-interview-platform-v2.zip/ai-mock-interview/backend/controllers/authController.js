const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/nedb');
const { validationResult } = require('express-validator');

const signToken = (id, role) =>
  jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || '30d' });

const safeUser = (u) => { if (!u) return null; const { password, ...rest } = u; return rest; };

exports.register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  const { name, email, password, profile = {} } = req.body;
  try {
    const existing = await db.users.findOne({ email: email.toLowerCase() });
    if (existing) return res.status(400).json({ success: false, message: 'Email already registered' });
    const hashed = await bcrypt.hash(password, 12);
    const now = new Date().toISOString();
    const user = await db.users.insert({
      name, email: email.toLowerCase(), password: hashed, role: 'candidate',
      profile: { avatar:'',phone:'',location:'',bio:'',skills:[],experience:0,targetRole:'',linkedIn:'',github:'',...profile },
      stats: { totalInterviews:0,averageScore:0,bestScore:0,totalTimeSpent:0,streak:0,lastInterviewDate:null },
      preferences: { difficulty:'medium',interviewDuration:30,preferredDomains:[],notificationsEnabled:true },
      isActive:true, lastLogin:now, createdAt:now, updatedAt:now,
    });
    res.status(201).json({ success:true, message:'Registration successful', token:signToken(user._id,user.role), user:safeUser(user) });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ success:false, message:'Provide email and password' });
  try {
    const user = await db.users.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ success:false, message:'Invalid credentials' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ success:false, message:'Invalid credentials' });
    if (!user.isActive) return res.status(403).json({ success:false, message:'Account deactivated' });
    await db.users.update({ _id:user._id }, { $set:{ lastLogin:new Date().toISOString() } });
    res.json({ success:true, message:'Login successful', token:signToken(user._id,user.role), user:safeUser(user) });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

exports.getMe = async (req, res) => {
  try {
    const user = await db.users.findOne({ _id:req.user._id });
    res.json({ success:true, user:safeUser(user) });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

exports.updatePassword = async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  try {
    const user = await db.users.findOne({ _id:req.user._id });
    if (!await bcrypt.compare(currentPassword, user.password))
      return res.status(401).json({ success:false, message:'Current password incorrect' });
    await db.users.update({ _id:user._id }, { $set:{ password: await bcrypt.hash(newPassword,12) } });
    res.json({ success:true, message:'Password updated', token:signToken(user._id,user.role) });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
};

exports.logout = (req, res) => res.json({ success:true, message:'Logged out' });
