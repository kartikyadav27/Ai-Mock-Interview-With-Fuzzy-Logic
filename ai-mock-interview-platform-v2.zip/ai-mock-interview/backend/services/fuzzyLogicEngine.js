/**
 * ================================================================
 * FUZZY LOGIC ENGINE — Mamdani Fuzzy Inference System
 * AI Mock Interview Platform
 * ================================================================
 * Input Variables (0–10): keywordCoverage, answerLength,
 *   aiConfidence, timeEfficiency, coherence
 * Output Variable (0–100): performanceScore
 * Fuzzy Sets: Poor | Average | Good | Excellent
 * Defuzzification: Centroid Method
 *
 * Strategy: Instead of matching all 5 inputs exactly (combinatorial
 * explosion), we aggregate the dominant membership level and fire
 * a single weighted rule. This gives smooth, predictable scoring.
 * ================================================================
 */
class FuzzyLogicEngine {
  constructor() {
    // Input MF params — domain [0, 10]
    this.inputSets = {
      poor:      { type: 'trap', p: [0,   0,   2,   4.5] },
      average:   { type: 'tri',  p: [2,   5,   7.5]      },
      good:      { type: 'tri',  p: [5,   7.5, 9.5]      },
      excellent: { type: 'trap', p: [7.5, 9,   10,  10]  },
    };

    // Output MF params — domain [0, 100]
    this.outputSets = {
      poor:      { type: 'trap', p: [0,  0,  20, 40]     },
      average:   { type: 'tri',  p: [20, 50, 65]          },
      good:      { type: 'tri',  p: [50, 70, 85]          },
      excellent: { type: 'trap', p: [75, 85, 100, 100]    },
    };
  }

  // ── Membership functions ──────────────────────────────────────

  _trap(x, a, b, c, d) {
    if (x < a || x > d) return 0;
    if (x >= b && x <= c) return 1;
    if (x >= a && x < b) return b === a ? 1 : (x - a) / (b - a);
    if (x > c && x <= d) return d === c ? 1 : (d - x) / (d - c);
    return 0;
  }

  _tri(x, a, b, c) {
    if (x <= a || x >= c) return 0;
    if (x === b) return 1;
    if (x < b) return (x - a) / (b - a);
    return (c - x) / (c - b);
  }

  _mu(x, setDef) {
    return setDef.type === 'trap'
      ? this._trap(x, ...setDef.p)
      : this._tri(x, ...setDef.p);
  }

  /** Fuzzify a crisp value (0–10) → membership degrees for all 4 sets */
  fuzzify(v) {
    const x = Math.min(10, Math.max(0, v));
    return {
      poor:      this._mu(x, this.inputSets.poor),
      average:   this._mu(x, this.inputSets.average),
      good:      this._mu(x, this.inputSets.good),
      excellent: this._mu(x, this.inputSets.excellent),
    };
  }

  /**
   * Aggregate 5 fuzzified inputs into a single weighted output.
   *
   * Strategy:
   *   1. For each input, get the dominant set (highest membership).
   *   2. Map dominant sets → numeric level: poor=1 avg=2 good=3 exc=4
   *   3. Compute weighted average across all 5 dimensions.
   *   4. Map weighted average back to output activation.
   *
   * This avoids the combinatorial rule explosion of a full 5-input
   * Mamdani system while preserving the fuzzy membership semantics.
   */
  applyRules(fuzzifiedInputs) {
    const setOrder = ['poor', 'average', 'good', 'excellent'];
    const setScore = { poor: 1, average: 2, good: 3, excellent: 4 };

    // Weights for each dimension
    const weights = [0.30, 0.20, 0.25, 0.10, 0.15]; // kw, len, conf, time, coh

    let weightedSum = 0;
    let maxActivation = 0;
    const details = [];

    fuzzifiedInputs.forEach((fz, i) => {
      // Find dominant set and its degree
      let domSet = 'poor', domDeg = 0;
      for (const s of setOrder) {
        if (fz[s] > domDeg) { domDeg = fz[s]; domSet = s; }
      }
      // Weighted contribution (1–4 scale)
      weightedSum += setScore[domSet] * domDeg * weights[i];
      maxActivation += domDeg * weights[i];
      details.push(`dim${i}=${domSet}(${domDeg.toFixed(2)})`);
    });

    // Normalise to 1–4 scale
    const avgLevel = maxActivation > 0 ? weightedSum / maxActivation : 1;

    // Map 1–4 level to output set activations using smooth interpolation
    const out = { poor: 0, average: 0, good: 0, excellent: 0 };

    if (avgLevel <= 1.5) {
      out.poor = 1 - (avgLevel - 1) / 0.5;
      out.average = (avgLevel - 1) / 0.5;
    } else if (avgLevel <= 2.5) {
      out.average = 1 - Math.abs(avgLevel - 2) / 0.5;
      if (avgLevel < 2) out.poor = Math.abs(avgLevel - 2) / 0.5;
      else              out.good = Math.abs(avgLevel - 2) / 0.5;
    } else if (avgLevel <= 3.5) {
      out.good = 1 - Math.abs(avgLevel - 3) / 0.5;
      if (avgLevel < 3) out.average = Math.abs(avgLevel - 3) / 0.5;
      else              out.excellent = Math.abs(avgLevel - 3) / 0.5;
    } else {
      out.excellent = 1 - (4 - avgLevel) / 0.5;
      out.good = (4 - avgLevel) / 0.5;
    }

    // Clamp
    for (const k of Object.keys(out)) out[k] = Math.max(0, Math.min(1, out[k]));

    const firedRules = [{
      rule: `WeightedAggregate: ${details.join(', ')} → level=${avgLevel.toFixed(2)}`,
      fired: true,
      confidence: maxActivation,
    }];

    return { outputActivations: out, firedRules };
  }

  /** Centroid defuzzification — output domain [0, 100] */
  defuzzify(act) {
    const N = 500;
    let num = 0, den = 0;
    for (let i = 0; i <= N; i++) {
      const x = (i / N) * 100;
      let mu = 0;
      for (const [k, alpha] of Object.entries(act)) {
        if (alpha > 0) {
          const m = Math.min(alpha, this._mu(x, this.outputSets[k]));
          if (m > mu) mu = m;
        }
      }
      num += x * mu;
      den += mu;
    }
    return den < 1e-6 ? 0 : num / den;
  }

  // ── Crisp input calculators ──────────────────────────────────

  calculateKeywordCoverage(answer, keywords) {
    if (!keywords || keywords.length === 0) return 5;
    const low = answer.toLowerCase();
    const n = keywords.filter(k => low.includes(k.toLowerCase())).length;
    return Math.min(10, (n / keywords.length) * 10);
  }

  calculateLengthScore(answer) {
    const wc = answer.trim().split(/\s+/).filter(Boolean).length;
    if (wc < 5)    return 1;
    if (wc < 15)   return 3;
    if (wc < 30)   return 5;
    if (wc < 60)   return 7;
    if (wc <= 200) return 10;
    if (wc <= 400) return 8;
    return 6;
  }

  calculateTimeEfficiency(timeSpent, timeLimit) {
    if (!timeSpent || !timeLimit) return 5;
    const r = timeSpent / timeLimit;
    if (r < 0.15) return 3;
    if (r < 0.35) return 6;
    if (r < 0.75) return 10;
    if (r <= 1.0)  return 7;
    return 4;
  }

  // ── Main entry point ─────────────────────────────────────────

  evaluate({ answer, expectedAnswer, keywords = [], timeSpent = 60, timeLimit = 120, aiRelevanceScore = 5, aiCoherenceScore = 5 }) {
    if (!answer || answer.trim().length < 3) return this.getEmptyResult();

    const kw   = this.calculateKeywordCoverage(answer, keywords);
    const len  = this.calculateLengthScore(answer);
    const conf = Math.min(10, Math.max(0, aiRelevanceScore));
    const time = this.calculateTimeEfficiency(timeSpent, timeLimit);
    const coh  = Math.min(10, Math.max(0, aiCoherenceScore));

    const fz = [
      this.fuzzify(kw),
      this.fuzzify(len),
      this.fuzzify(conf),
      this.fuzzify(time),
      this.fuzzify(coh),
    ];

    const { outputActivations, firedRules } = this.applyRules(fz);
    const crispScore = this.defuzzify(outputActivations);
    const finalScore = Math.round(Math.min(100, Math.max(1, crispScore)));

    return {
      crispInputs: {
        relevance:      Math.round(kw   * 10) / 10,
        completeness:   Math.round(len  * 10) / 10,
        clarity:        Math.round(conf * 10) / 10,
        technicalDepth: Math.round(time * 10) / 10,
        communication:  Math.round(coh  * 10) / 10,
      },
      fuzzyMembership: outputActivations,
      finalScore,
      grade: this.getGrade(finalScore),
      firedRules,
    };
  }

  getGrade(score) {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Average';
    return 'Poor';
  }

  getEmptyResult() {
    return {
      crispInputs: { relevance: 0, completeness: 0, clarity: 0, technicalDepth: 0, communication: 0 },
      fuzzyMembership: { poor: 1, average: 0, good: 0, excellent: 0 },
      finalScore: 0,
      grade: 'Not Answered',
      firedRules: [],
    };
  }
}

module.exports = new FuzzyLogicEngine();
