const fuzzyEngine = require('./fuzzyLogicEngine');

class AIEvaluationService {
  constructor() {
    this.hasOpenAI = !!(process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.startsWith('sk-'));
    if (this.hasOpenAI) {
      try {
        const OpenAI = require('openai');
        this.client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
        console.log('✅ OpenAI connected');
      } catch(e) {
        this.hasOpenAI = false;
      }
    } else {
      console.log('ℹ️  OpenAI key not set — using built-in fuzzy evaluation only');
    }
  }

  async generateQuestions(domain, difficulty, count = 5, category = 'technical') {
    if (!this.hasOpenAI) return this._fallbackQuestions(domain, difficulty, count, category);
    try {
      const prompt = `Generate ${count} ${difficulty} ${category} interview questions for ${domain}.
Return ONLY a JSON array, no markdown:
[{"text":"question","expectedAnswer":"detailed answer","keywords":["k1","k2","k3"],"hints":["hint1"],"followUpQuestions":["follow up"],"timeLimit":120,"difficultyScore":5}]`;
      const response = await this.client.chat.completions.create({
        model: 'gpt-3.5-turbo', messages:[{role:'user',content:prompt}], temperature:0.7, max_tokens:2000,
      });
      const content = response.choices[0].message.content;
      const match = content.match(/\[[\s\S]*\]/);
      return match ? JSON.parse(match[0]) : this._fallbackQuestions(domain, difficulty, count, category);
    } catch (e) {
      console.error('OpenAI generate failed:', e.message);
      return this._fallbackQuestions(domain, difficulty, count, category);
    }
  }

  async evaluateAnswer(question, userAnswer, timeSpent, timeLimit) {
    if (!userAnswer || !userAnswer.trim()) return fuzzyEngine.getEmptyResult();

    let aiRelevanceScore = 5, aiCoherenceScore = 5;
    let feedback = '', strengths = [], improvements = [], modelAnswer = question.expectedAnswer || '';

    if (this.hasOpenAI) {
      try {
        const prompt = `You are an expert interviewer. Evaluate this answer.
Question: ${question.text}
Expected: ${question.expectedAnswer}
Candidate: ${userAnswer}
Return ONLY JSON (no markdown):
{"relevanceScore":7,"coherenceScore":7,"feedback":"2-3 sentence feedback","strengths":["s1","s2"],"improvements":["i1","i2"],"modelAnswer":"brief model answer"}`;
        const response = await this.client.chat.completions.create({
          model:'gpt-3.5-turbo', messages:[{role:'user',content:prompt}], temperature:0.3, max_tokens:600,
        });
        const content = response.choices[0].message.content.replace(/```json|```/g,'').trim();
        const parsed = JSON.parse(content);
        aiRelevanceScore = Math.min(10, Math.max(0, parsed.relevanceScore || 5));
        aiCoherenceScore = Math.min(10, Math.max(0, parsed.coherenceScore || 5));
        feedback = parsed.feedback || '';
        strengths = parsed.strengths || [];
        improvements = parsed.improvements || [];
        modelAnswer = parsed.modelAnswer || question.expectedAnswer;
      } catch(e) { console.error('AI eval error:', e.message); }
    } else {
      // Smart fallback: keyword-based scoring
      const keywords = question.keywords || [];
      const lowerAnswer = userAnswer.toLowerCase();
      const found = keywords.filter(k => lowerAnswer.includes(k.toLowerCase()));
      aiRelevanceScore = keywords.length > 0 ? Math.min(10, (found.length / keywords.length) * 10) : 5;
      aiCoherenceScore = userAnswer.split(' ').length > 20 ? 7 : 4;
      feedback = `Answer evaluated using keyword matching. ${found.length}/${keywords.length} key concepts covered.`;
      strengths = found.length > 0 ? [`Covered: ${found.slice(0,3).join(', ')}`] : ['Attempted the question'];
      improvements = keywords.filter(k => !lowerAnswer.includes(k.toLowerCase())).slice(0,2).map(k => `Include concept: ${k}`);
      modelAnswer = question.expectedAnswer || '';
    }

    const fuzzyResult = fuzzyEngine.evaluate({
      answer: userAnswer, expectedAnswer: question.expectedAnswer,
      keywords: question.keywords || [], timeSpent,
      timeLimit: timeLimit || question.timeLimit || 120,
      aiRelevanceScore, aiCoherenceScore,
    });

    return { ...fuzzyResult, aiEvaluation: { feedback, strengths, improvements, modelAnswer } };
  }

  async generateSessionFeedback({ domain, answers, finalScore }) {
    if (!this.hasOpenAI) return this._fallbackFeedback(domain, answers, finalScore);
    try {
      const summary = answers.slice(0,5).map((a,i) => `Q${i+1}: ${a.finalScore||0}/100 - ${a.grade}`).join('\n');
      const prompt = `Expert interviewer feedback for a ${domain} interview.
Score: ${finalScore}/100
Answers: ${summary}
Return ONLY JSON (no markdown):
{"overallFeedback":"3-4 sentences","topStrengths":["s1","s2","s3"],"areasForImprovement":["a1","a2","a3"],"recommendedResources":["r1","r2"],"hiringRecommendation":"Hire"}`;
      const response = await this.client.chat.completions.create({
        model:'gpt-3.5-turbo', messages:[{role:'user',content:prompt}], temperature:0.4, max_tokens:600,
      });
      const content = response.choices[0].message.content.replace(/```json|```/g,'').trim();
      return JSON.parse(content);
    } catch(e) {
      console.error('Session feedback error:', e.message);
      return this._fallbackFeedback(domain, answers, finalScore);
    }
  }

  _fallbackFeedback(domain, answers, finalScore) {
    const answered = answers.filter(a => !a.isSkipped && a.finalScore > 0);
    const avgScore = answered.length > 0 ? Math.round(answered.reduce((s,a)=>s+a.finalScore,0)/answered.length) : 0;
    return {
      overallFeedback: `You scored ${finalScore}/100 on this ${domain} interview. ${finalScore >= 70 ? 'Great performance! You demonstrated solid knowledge.' : finalScore >= 50 ? 'Decent attempt. With more practice you can improve significantly.' : 'Keep practicing. Focus on core concepts and fundamentals.'}`,
      topStrengths: answered.filter(a=>a.finalScore>=70).slice(0,3).map((_,i) => ['Good conceptual clarity','Structured responses','Relevant examples'][i]) || ['Attempted all questions'],
      areasForImprovement: ['Review core fundamentals', 'Practice explaining concepts clearly', 'Work on time management'],
      recommendedResources: [`${domain} official documentation`, 'LeetCode Practice', 'System Design Primer', 'MDN Web Docs'],
      hiringRecommendation: finalScore >= 75 ? 'Strong Hire' : finalScore >= 60 ? 'Hire' : finalScore >= 45 ? 'Consider' : 'No Hire',
    };
  }

  _fallbackQuestions(domain, difficulty, count, category) {
    const bank = {
      JavaScript: [
        { text:"Explain closures in JavaScript with an example.", expectedAnswer:"A closure is a function that retains access to its outer scope even after the outer function returns. Example: function counter(){ let n=0; return ()=>++n; } const c=counter(); c(); // 1", keywords:["closure","scope","lexical","outer function"], hints:["How does a function remember variables?"], timeLimit:150, difficultyScore:5 },
        { text:"What is the difference between var, let, and const?", expectedAnswer:"var: function-scoped, hoisted. let: block-scoped, not hoisted. const: block-scoped, must be initialised, cannot be reassigned.", keywords:["var","let","const","scope","hoisting","block"], hints:["Think about scope and mutability"], timeLimit:90, difficultyScore:2 },
        { text:"Explain the Event Loop in JavaScript.", expectedAnswer:"The Event Loop monitors the Call Stack and Callback Queue. When the call stack is empty it picks callbacks from the queue. Microtasks (Promises) run before macrotasks (setTimeout).", keywords:["event loop","call stack","callback queue","microtask","macrotask"], hints:["What happens when async code completes?"], timeLimit:180, difficultyScore:7 },
        { text:"What are Promises and how do they work?", expectedAnswer:"A Promise represents a future value. It has 3 states: pending, fulfilled, rejected. Use .then() for success, .catch() for errors, async/await for cleaner syntax.", keywords:["promise","pending","fulfilled","rejected","async","await"], hints:["What problem do Promises solve?"], timeLimit:120, difficultyScore:5 },
        { text:"Explain prototypal inheritance in JavaScript.", expectedAnswer:"Objects inherit directly from other objects via the prototype chain. Every object has __proto__ linking to its prototype. Object.create() creates objects with a specific prototype.", keywords:["prototype","__proto__","inheritance","chain","Object.create"], hints:["How does JS look up properties?"], timeLimit:150, difficultyScore:7 },
      ],
      Python: [
        { text:"What are Python decorators? Write a simple example.", expectedAnswer:"Decorators wrap functions to modify behaviour without changing source code. @syntax sugar. def timer(fn): def wrap(*a): t=time.time(); r=fn(*a); print(time.time()-t); return r; return wrap", keywords:["decorator","wrapper","@","higher-order","function"], hints:["What does @ do syntactically?"], timeLimit:150, difficultyScore:6 },
        { text:"Explain list comprehensions in Python.", expectedAnswer:"Concise syntax to create lists: [expression for item in iterable if condition]. Example: [x**2 for x in range(10) if x%2==0]. More readable and often faster than for loops.", keywords:["list comprehension","expression","iterable","filter","concise"], hints:["How would you write it as a for loop?"], timeLimit:90, difficultyScore:3 },
        { text:"What is the difference between *args and **kwargs?", expectedAnswer:"*args collects extra positional arguments as a tuple. **kwargs collects extra keyword arguments as a dict. Used to write flexible functions accepting variable numbers of arguments.", keywords:["*args","**kwargs","positional","keyword","tuple","dict"], hints:["What does * do to a variable?"], timeLimit:90, difficultyScore:4 },
      ],
      React: [
        { text:"What are React Hooks? Explain useState and useEffect.", expectedAnswer:"Hooks let functional components use state and lifecycle features. useState returns [state, setter]. useEffect runs side effects after render with optional dependency array for control.", keywords:["hooks","useState","useEffect","functional","dependency array","side effects"], hints:["What problem did hooks solve?"], timeLimit:150, difficultyScore:5 },
        { text:"Explain the virtual DOM and how React uses it.", expectedAnswer:"Virtual DOM is a lightweight in-memory representation of the real DOM. React diffs the new vDOM against the previous one (reconciliation) and only updates changed real DOM nodes (patching).", keywords:["virtual DOM","reconciliation","diffing","render","patch","performance"], hints:["Why is direct DOM manipulation slow?"], timeLimit:120, difficultyScore:5 },
        { text:"What is the Context API and when would you use it?", expectedAnswer:"Context provides a way to pass data through the component tree without prop drilling. Create context, provide value at top, consume with useContext hook. Use for themes, auth, language.", keywords:["context","useContext","provider","consumer","prop drilling"], hints:["What problem does it solve vs props?"], timeLimit:120, difficultyScore:6 },
      ],
      'Data Structures': [
        { text:"Explain the difference between a stack and a queue with real-world examples.", expectedAnswer:"Stack: LIFO — push/pop. Examples: browser back button, undo, call stack. Queue: FIFO — enqueue/dequeue. Examples: print queue, CPU scheduling, message queues.", keywords:["LIFO","FIFO","stack","queue","push","pop","enqueue","dequeue"], hints:["Think about order of operations"], timeLimit:120, difficultyScore:2 },
        { text:"What is a binary search tree and what are its time complexities?", expectedAnswer:"BST: left child < parent < right child. Search/insert/delete: O(log n) average, O(n) worst case (unbalanced). In-order traversal gives sorted output.", keywords:["BST","binary search tree","O(log n)","balanced","traversal","insert","delete"], hints:["What makes it faster than a regular array search?"], timeLimit:150, difficultyScore:5 },
        { text:"Explain Big O notation with examples.", expectedAnswer:"Big O describes worst-case growth rate. O(1): array access. O(log n): binary search. O(n): linear search. O(n log n): merge sort. O(n²): bubble sort, nested loops.", keywords:["Big O","O(1)","O(n)","O(log n)","O(n²)","complexity","growth"], hints:["How does runtime scale with input size?"], timeLimit:150, difficultyScore:4 },
      ],
      'System Design': [
        { text:"How would you design a URL shortening service like bit.ly?", expectedAnswer:"Components: API to accept URL, hash/base62 for short code, DB (NoSQL) for mapping, redirect service (301/302), Redis cache for popular URLs. Consider: collision handling, analytics, rate limiting, custom aliases.", keywords:["hashing","base62","database","cache","Redis","redirect","scalability","collision"], hints:["What are the core operations needed?"], timeLimit:300, difficultyScore:8 },
        { text:"Design a rate limiter for an API.", expectedAnswer:"Options: Token bucket, Leaky bucket, Fixed window, Sliding window algorithms. Store counts in Redis with TTL. Add headers X-RateLimit-Remaining. Return 429 on exceed. Consider distributed systems.", keywords:["rate limiter","token bucket","Redis","sliding window","429","distributed"], hints:["Where do you store the count?"], timeLimit:300, difficultyScore:8 },
      ],
      Algorithms: [
        { text:"Explain merge sort and its time complexity.", expectedAnswer:"Divide array in half recursively until single elements, then merge sorted halves. Time: O(n log n) all cases. Space: O(n). Stable sort. Better than quicksort for linked lists and external sorting.", keywords:["merge sort","divide","conquer","O(n log n)","stable","recursive","merge"], hints:["How do you combine two sorted arrays?"], timeLimit:180, difficultyScore:6 },
        { text:"What is dynamic programming? Give an example.", expectedAnswer:"DP solves problems by breaking into overlapping subproblems and storing results (memoisation/tabulation) to avoid recomputation. Example: Fibonacci with memo turns O(2^n) to O(n).", keywords:["dynamic programming","memoisation","tabulation","overlapping","subproblems","optimal"], hints:["What's the difference from divide and conquer?"], timeLimit:180, difficultyScore:7 },
      ],
      Database: [
        { text:"Explain the difference between SQL and NoSQL databases.", expectedAnswer:"SQL: relational, ACID, fixed schema, vertical scaling, joins. Use for: transactions, complex queries. NoSQL: flexible schema, horizontal scaling, various models (doc/KV/graph). Use for: unstructured data, high traffic.", keywords:["SQL","NoSQL","ACID","relational","schema","horizontal","vertical","scaling"], hints:["What does ACID stand for?"], timeLimit:150, difficultyScore:4 },
        { text:"What are database indexes and why are they important?", expectedAnswer:"Indexes are data structures (usually B-tree) that speed up data retrieval. Trade-off: faster reads, slower writes, extra storage. Should index frequently queried columns. Avoid over-indexing.", keywords:["index","B-tree","query","performance","trade-off","write","read"], hints:["How does a book index work?"], timeLimit:120, difficultyScore:5 },
      ],
      Behavioral: [
        { text:"Tell me about a time you faced a significant technical challenge. How did you overcome it?", expectedAnswer:"Use STAR: Situation (context), Task (your role), Action (specific steps taken), Result (outcome with metrics). Show problem-solving, persistence, learning.", keywords:["STAR","challenge","solution","result","learning","action","outcome"], hints:["Use the STAR framework","Quantify results"], timeLimit:180, difficultyScore:5 },
        { text:"Describe a situation where you had to work with a difficult team member.", expectedAnswer:"STAR format. Show: empathy, communication skills, conflict resolution, focus on outcomes, professionalism. Avoid blaming. Highlight what you learned.", keywords:["communication","conflict","teamwork","resolution","empathy","professional"], hints:["Focus on what you did, not what they did"], timeLimit:180, difficultyScore:5 },
      ],
      'Node.js': [
        { text:"Explain middleware in Express.js and write an example.", expectedAnswer:"Middleware are functions with (req,res,next) that run in the request pipeline. Can modify req/res, end cycle, or call next(). Example: const logger=(req,res,next)=>{console.log(req.method,req.path);next();}; app.use(logger);", keywords:["middleware","req","res","next","pipeline","Express","app.use"], hints:["What does next() do?"], timeLimit:150, difficultyScore:5 },
        { text:"What is the Node.js event loop and how does it handle async operations?", expectedAnswer:"Node.js is single-threaded but uses libuv for async I/O. The event loop has phases: timers, I/O callbacks, idle, poll, check, close. Async ops go to thread pool, callbacks queued when done.", keywords:["event loop","libuv","async","non-blocking","phases","single-threaded","callback"], hints:["How can Node handle many connections with one thread?"], timeLimit:180, difficultyScore:7 },
      ],
      'Machine Learning': [
        { text:"Explain overfitting and how to prevent it.", expectedAnswer:"Overfitting: model learns training data noise, fails on new data (high variance). Prevention: regularisation (L1/L2), dropout, cross-validation, early stopping, more data, simpler model.", keywords:["overfitting","variance","regularisation","dropout","cross-validation","generalisation"], hints:["What's the difference between training and test error?"], timeLimit:150, difficultyScore:6 },
        { text:"What is gradient descent and how does it work?", expectedAnswer:"Optimisation algorithm that iteratively adjusts parameters in the direction of steepest descent of the loss function. Learning rate controls step size. Variants: batch, stochastic (SGD), mini-batch.", keywords:["gradient descent","learning rate","loss function","parameters","SGD","optimisation","convergence"], hints:["What does the gradient tell you?"], timeLimit:150, difficultyScore:6 },
      ],
      HR: [
        { text:"Why do you want to work at our company?", expectedAnswer:"Research the company. Show: alignment with mission/values, specific interest in their products/tech stack, growth opportunity, contribution you can make. Be specific, not generic.", keywords:["mission","values","culture","growth","contribution","specific","research"], hints:["Research the company before answering","Be specific not generic"], timeLimit:90, difficultyScore:3 },
        { text:"Where do you see yourself in 5 years?", expectedAnswer:"Show ambition with realism. Align with company growth. Mention: skill development, leadership interest, contributing to bigger projects, continuous learning. Avoid 'in your position'.", keywords:["growth","goals","skills","leadership","learning","ambition","contribute"], hints:["Show ambition but be realistic","Align with company direction"], timeLimit:90, difficultyScore:2 },
      ],
    };

    const domainQs = bank[domain] || bank['JavaScript'];
    const selected = domainQs.sort(() => 0.5 - Math.random()).slice(0, Math.min(count, domainQs.length));
    return selected.map(q => ({ ...q, followUpQuestions: q.followUpQuestions || [] }));
  }
}

module.exports = new AIEvaluationService();
