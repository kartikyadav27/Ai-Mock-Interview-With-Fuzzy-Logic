const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  text: {
    type: String,
    required: [true, 'Question text is required'],
    trim: true,
  },
  domain: {
    type: String,
    required: true,
    enum: [
      'JavaScript', 'Python', 'Java', 'C++', 'React', 'Node.js',
      'Data Structures', 'Algorithms', 'System Design', 'Database',
      'Machine Learning', 'DevOps', 'Behavioral', 'HR', 'General',
    ],
  },
  category: {
    type: String,
    enum: ['technical', 'behavioral', 'situational', 'hr', 'coding'],
    required: true,
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    required: true,
  },
  difficultyScore: {
    type: Number,  // 1-10 numerical difficulty
    min: 1,
    max: 10,
  },
  expectedAnswer: {
    type: String,
    required: true,
  },
  keywords: [{ type: String }],  // Key terms expected in answer
  followUpQuestions: [{ type: String }],
  hints: [{ type: String }],
  timeLimit: {
    type: Number,
    default: 120, // seconds
  },
  tags: [{ type: String }],
  isActive: { type: Boolean, default: true },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  usageCount: { type: Number, default: 0 },
  avgScore: { type: Number, default: 0 },
}, {
  timestamps: true,
});

questionSchema.index({ domain: 1, difficulty: 1, category: 1 });
questionSchema.index({ tags: 1 });

module.exports = mongoose.model('Question', questionSchema);
