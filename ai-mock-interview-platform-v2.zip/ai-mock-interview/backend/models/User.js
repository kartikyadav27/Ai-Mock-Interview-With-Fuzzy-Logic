const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [50, 'Name cannot exceed 50 characters'],
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Invalid email'],
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters'],
    select: false,
  },
  role: {
    type: String,
    enum: ['candidate', 'admin'],
    default: 'candidate',
  },
  profile: {
    avatar: { type: String, default: '' },
    phone: { type: String, default: '' },
    location: { type: String, default: '' },
    bio: { type: String, default: '' },
    skills: [{ type: String }],
    experience: { type: Number, default: 0 }, // years
    targetRole: { type: String, default: '' },
    targetCompany: { type: String, default: '' },
    linkedIn: { type: String, default: '' },
    github: { type: String, default: '' },
  },
  stats: {
    totalInterviews: { type: Number, default: 0 },
    averageScore: { type: Number, default: 0 },
    bestScore: { type: Number, default: 0 },
    totalTimeSpent: { type: Number, default: 0 }, // minutes
    streak: { type: Number, default: 0 },
    lastInterviewDate: { type: Date },
  },
  preferences: {
    difficulty: { type: String, enum: ['easy', 'medium', 'hard'], default: 'medium' },
    interviewDuration: { type: Number, default: 30 }, // minutes
    preferredDomains: [{ type: String }],
    notificationsEnabled: { type: Boolean, default: true },
  },
  isEmailVerified: { type: Boolean, default: false },
  emailVerificationToken: String,
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  isActive: { type: Boolean, default: true },
  lastLogin: { type: Date },
}, {
  timestamps: true,
});

// Hash password before save
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Match password
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Generate JWT
userSchema.methods.getSignedJwtToken = function () {
  return jwt.sign({ id: this._id, role: this.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE,
  });
};

// Update stats after interview
userSchema.methods.updateStats = async function (score, duration) {
  this.stats.totalInterviews += 1;
  this.stats.totalTimeSpent += duration;
  this.stats.lastInterviewDate = new Date();
  if (score > this.stats.bestScore) this.stats.bestScore = score;

  // Recalculate average
  const total = this.stats.averageScore * (this.stats.totalInterviews - 1) + score;
  this.stats.averageScore = Math.round(total / this.stats.totalInterviews);

  // Update streak
  const today = new Date();
  const lastDate = this.stats.lastInterviewDate;
  if (lastDate) {
    const diff = Math.floor((today - lastDate) / (1000 * 60 * 60 * 24));
    this.stats.streak = diff <= 1 ? this.stats.streak + 1 : 1;
  } else {
    this.stats.streak = 1;
  }
  await this.save();
};

module.exports = mongoose.model('User', userSchema);
