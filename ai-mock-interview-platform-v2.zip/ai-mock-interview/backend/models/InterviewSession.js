const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema({
  questionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Question',
    required: true,
  },
  questionText: String,
  answerText: { type: String, default: '' },
  timeSpent: { type: Number, default: 0 }, // seconds

  // Fuzzy Logic Scores (0-10)
  fuzzyScores: {
    relevance: { type: Number, default: 0 },       // How relevant the answer is
    completeness: { type: Number, default: 0 },    // How complete the answer is
    clarity: { type: Number, default: 0 },         // How clear/articulate
    technicalDepth: { type: Number, default: 0 },  // Technical accuracy
    communication: { type: Number, default: 0 },   // Communication quality
  },

  // Fuzzy membership values
  fuzzyMembership: {
    poor: { type: Number, default: 0 },
    average: { type: Number, default: 0 },
    good: { type: Number, default: 0 },
    excellent: { type: Number, default: 0 },
  },

  // Final defuzzified score (0-100)
  finalScore: { type: Number, default: 0 },
  grade: {
    type: String,
    enum: ['Excellent', 'Good', 'Average', 'Poor', 'Not Answered'],
    default: 'Not Answered',
  },

  aiEvaluation: {
    feedback: { type: String, default: '' },
    strengths: [{ type: String }],
    improvements: [{ type: String }],
    modelAnswer: { type: String, default: '' },
  },

  isSkipped: { type: Boolean, default: false },
});

const interviewSessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  title: { type: String, default: 'Mock Interview' },
  domain: { type: String, required: true },
  category: { type: String, required: true },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard', 'mixed'],
    default: 'medium',
  },
  status: {
    type: String,
    enum: ['scheduled', 'in_progress', 'completed', 'cancelled', 'abandoned'],
    default: 'scheduled',
  },
  questions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Question' }],
  answers: [answerSchema],
  totalQuestions: { type: Number, default: 0 },
  answeredQuestions: { type: Number, default: 0 },
  skippedQuestions: { type: Number, default: 0 },

  // Timing
  scheduledAt: { type: Date },
  startedAt: { type: Date },
  completedAt: { type: Date },
  duration: { type: Number, default: 0 }, // actual duration in seconds
  timeLimit: { type: Number, default: 1800 }, // 30 min default

  // Overall Fuzzy Logic Result
  overallFuzzyScore: {
    relevance: { type: Number, default: 0 },
    completeness: { type: Number, default: 0 },
    clarity: { type: Number, default: 0 },
    technicalDepth: { type: Number, default: 0 },
    communication: { type: Number, default: 0 },
  },
  finalScore: { type: Number, default: 0 },     // 0-100
  percentile: { type: Number, default: 0 },
  grade: {
    type: String,
    enum: ['Excellent', 'Good', 'Average', 'Poor', 'N/A'],
    default: 'N/A',
  },

  // AI Analysis
  aiAnalysis: {
    overallFeedback: { type: String, default: '' },
    topStrengths: [{ type: String }],
    areasForImprovement: [{ type: String }],
    recommendedResources: [{ type: String }],
    hiringRecommendation: {
      type: String,
      enum: ['Strong Hire', 'Hire', 'Consider', 'No Hire', 'N/A'],
      default: 'N/A',
    },
  },

  // Fuzzy Logic Rule Firing Summary
  fuzzyRulesSummary: [{
    rule: String,
    fired: Boolean,
    confidence: Number,
  }],

  isPublic: { type: Boolean, default: false },
  notes: { type: String, default: '' },
}, {
  timestamps: true,
});

interviewSessionSchema.index({ userId: 1, status: 1 });
interviewSessionSchema.index({ createdAt: -1 });

module.exports = mongoose.model('InterviewSession', interviewSessionSchema);
