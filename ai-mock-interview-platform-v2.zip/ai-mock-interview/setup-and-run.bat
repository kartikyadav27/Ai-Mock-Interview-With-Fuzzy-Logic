@echo off
title AI Mock Interview Platform — Setup
color 0A

echo.
echo  ████████████████████████████████████████████████████████
echo  █                                                      █
echo  █      AI MOCK INTERVIEW PLATFORM — AUTO SETUP        █
echo  █         MERN Stack + Fuzzy Logic Engine              █
echo  █                                                      █
echo  ████████████████████████████████████████████████████████
echo.

:: Check Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found!
    echo Please install Node.js from https://nodejs.org (v18 or higher)
    echo.
    pause
    exit /b 1
)
echo [OK] Node.js found: 
node --version

:: Check npm
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] npm not found!
    pause
    exit /b 1
)
echo [OK] npm found

echo.
echo [1/4] Installing root dependencies...
call npm install
if %errorlevel% neq 0 ( echo [ERROR] Root install failed & pause & exit /b 1 )

echo.
echo [2/4] Installing backend dependencies...
cd backend
call npm install
if %errorlevel% neq 0 ( echo [ERROR] Backend install failed & pause & exit /b 1 )

echo.
echo [3/4] Installing frontend dependencies...
cd ../frontend
call npm install
if %errorlevel% neq 0 ( echo [ERROR] Frontend install failed & pause & exit /b 1 )

echo.
echo [4/4] Seeding database with sample data...
cd ../backend
call node seeder.js
if %errorlevel% neq 0 ( echo [WARN] Seeder failed - will retry on first run )

cd ..

echo.
echo  ████████████████████████████████████████████████████████
echo  █                                                      █
echo  █   SETUP COMPLETE! Starting the application...       █
echo  █                                                      █
echo  █   Backend  : http://localhost:5000                   █
echo  █   Frontend : http://localhost:3000                   █
echo  █                                                      █
echo  █   LOGIN:                                             █
echo  █   Email    : admin@mockinterview.com                 █
echo  █   Password : Admin@123456                            █
echo  █                                                      █
echo  █   (Browser will open automatically)                  █
echo  ████████████████████████████████████████████████████████
echo.

:: Start backend in new window
start "Backend Server" cmd /k "cd backend && npm run dev"

:: Wait for backend to start
timeout /t 4 /nobreak >nul

:: Start frontend in new window
start "Frontend Server" cmd /k "cd frontend && npm start"

:: Open browser
timeout /t 6 /nobreak >nul
start http://localhost:3000

echo.
echo Both servers are running in separate windows.
echo Close those windows to stop the servers.
echo.
pause
